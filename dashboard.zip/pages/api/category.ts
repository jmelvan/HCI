// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<any>
) {
  setTimeout(() => {
    res.status(200).json({
      "name": "Wine",
      "name_plural": "Wines",
      "created_at": "2022-12-08T13:34:02.348+01:00",
      "updated_at": "2022-12-08T13:34:02.353+01:00",
      "cover_image": "http://localhost:3000/assets/whiskey.png",
      "id": 15,
      "type_id": 1,
      "translations": [
        {
          "name": "Vino",
          "name_plural": "Vina",
          "language": "hr"
        }
      ],
      "type": {
        "id": 1,
        "name": "Drink",
        "name_plural": "Drinks",
        "collection_name": "Drinks collection",
        "created_at": "2022-11-30T23:58:09.958+01:00",
        "updated_at": "2022-11-30T23:58:09.959+01:00"
      },
      "attributes": [
        {
          "id": 32,
          "value": "White wine",
          "category_id": 15,
          "created_at": "2022-12-08T13:34:02.365+01:00",
          "updated_at": "2022-12-08T13:34:02.373+01:00",
          "translations": [
            {
              "value": "Bijelo vino",
              "language": "hr"
            }
          ]
        },
        {
          "id": 33,
          "value": "Red wine",
          "category_id": 15,
          "created_at": "2022-12-08T13:34:02.365+01:00",
          "updated_at": "2022-12-08T13:34:02.373+01:00",
          "translations": []
        },
      ]
    })
  }, 500)
}
