// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<any>
) {
  setTimeout(() => {
    res.status(200).json([
      {
        id: 8495,
        img: "assets/splitbar.png",
        name: 'Split bar'
      },
      {
        id: 8495,
        img: "assets/splitbar.png",
        name: 'Split bar'
      },
      {
        id: 8495,
        img: "assets/splitbar.png",
        name: 'Split bar'
      },
    ])
  }, 500)
}
