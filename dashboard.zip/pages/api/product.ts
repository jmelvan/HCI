// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<any>
) {
  setTimeout(() => {
    res.status(200).json({
      "name": "Wine",
      "created_at": "2022-12-08T13:34:02.348+01:00",
      "updated_at": "2022-12-08T13:34:02.353+01:00",
      "image": "http://localhost:3000/assets/whiskey.png",
      "id": 15,
      "category_id": 1,
      "tags": [1,2,3],
      "places": [1,2,3],
      "prices": [
        {
          "id": "1",
          "icon_id": "2",
          "size": "50ml",
          "price": "125hrk",
          "place_id": "1"
        },
        {
          "id": "1",
          "icon_id": "3",
          "size": "50ml",
          "price": "125hrk",
          "place_id": "1"
        }
      ],
      "translations":  [
        {
          "name": "Vino",
          "language": "hr"
        }
      ],
      "attributes": [
        {
          "id": "1",
          "order": "2",
          "type_id": "3",
          "value": {
            "key": "Alergens",
            "value": [
              {
                "key": "Milk",
                "value": "25%"
              },
              {
                "key": "Sugar",
                "value": "25mg"
              }
            ]
          },
          "translations": [
            {
              "value": {
                "key": "Alergeni",
                "value": [
                  {
                    "key": "Mliko",
                    "value": "25%"
                  },
                  {
                    "key": "Šećer",
                    "value": "25mg"
                  }
                ]
              },
              "language": "hr"
            }
          ]
        },
        {
          "id": "2",
          "type_id": "1",
          "order": "3",
          "value": {
            "key": "Description",
            "value": [
              {
                "value": "Neki opis"
              }
            ]
          },
          "translations": []
        }
      ]
    })
  }, 500)
}
