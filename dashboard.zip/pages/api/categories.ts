// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<any>
) {
  setTimeout(() => {
    res.status(200).json([
      {
        id: 8495,
        img: "assets/whiskey.png",
        name: 'Whiskey',
        name_plural: 'Whiskeys',
        type: 'Drink'
      },
      {
        id: 2395,
        img: "assets/whiskey.png",
        name: 'Whiskey',
        name_plural: 'Whiskeys',
        type: 'Drink'
      },
      {
        id: 4123,
        img: "assets/whiskey.png",
        name: 'Whiskey 3',
        name_plural: 'Whiskeys',
        type: 'Drink'
      },
      {
        id: 5452,
        img: "assets/whiskey.png",
        name: 'Whiskey 4',
        name_plural: 'Whiskeys',
        type: 'Drink'
      },
      {
        id: 5452,
        img: "assets/whiskey.png",
        name: 'Whiskey 5',
        name_plural: 'Whiskeys',
        type: 'Drink'
      },
      {
        id: 5452,
        img: "assets/whiskey.png",
        name: 'Whiskey 6',
        name_plural: 'Whiskeys',
        type: 'Drink'
      },
    ])
  }, 500)
}
