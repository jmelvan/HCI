// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<any>
) {
  setTimeout(() => {
    res.status(200).json([
      {
        id: 8495,
        img: "assets/whiskey.png",
        name: 'Yellow Spot 12 Year Single Pot Still',
        places: ["Bar 1", "Bar 2"],
        category: 'Whiskey'
      },
      {
        id: 3491,
        img: "assets/whiskey.png",
        name: 'Marština, Marko Sladić',
        places: ["Bar 1", "Bar 2", "Restaurant"],
        category: 'Wine'
      },
      {
        id: 5493,
        img: "assets/whiskey.png",
        name: 'Gin/Vodka Martini',
        places: ["Bar 2"],
        category: 'Coctail'
      },
      {
        id: 4946,
        img: "assets/whiskey.png",
        name: 'Single Pot Still',
        places: ["Bar 1", "Bar 2"],
        category: 'Whiskey'
      },
      {
        id: 2345,
        img: "assets/whiskey.png",
        name: 'Malvazija',
        places: ["Restaurant"],
        category: 'Wine'
      },
    ])
  }, 500)
}
