'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Sidebar from '../../components/sidebar'
import useAuth from '../../hooks/useAuth'
import { Poppins } from '@next/font/google'
import './style.scss'
import { navigation } from '../../config/navigation';
import DashboardProvider from '../../context/DashboardContext';
import MessagesProvider from '../../context/MessagesContext';

const poppins = Poppins({
  weight: ['400', '500', '600', '700'],
  subsets: ['latin'],
})

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  let { token, tokenLoaded } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [loading, setLoading] = useState(true);
  const [sidebarState, setSidebarState] = useState(false);
  const [pageNames, setPageNames] = useState<Record<string, string>>({});

  useEffect(() => {
    // initialize empty pages object
    let pages:Record<string, string> = {};
    // loop through animation and match labels with slugs
    navigation.map(({items}) => items.map(({label, slug, children}) => {
      pages[`/${slug}`] = label; // first level
      children?.map(child => (pages[`/${slug}/${child.slug}`] = child.label)) // second level (not shown in sidebar)
    }))
    // store page names to state
    setPageNames(pages);
  }, [])

  useEffect(() => setLoading(false), [tokenLoaded])

  // function to toggle sidebar on mob and on desktop
  const toggleSidebar = () => setSidebarState(prevState => !prevState);

  if(loading)
    return pageLoader;

  if(token === null || token === undefined) {
    router.replace('/login')
    return pageLoader;
  }

  return (
    <html lang="en">
      <head />
      <body className={poppins.className + (sidebarState ? " sidebar-opened" : "")}>
        <Sidebar toggle={toggleSidebar} />
        <div className="content-wrapper">
          <div className="content container">

            {/* Start of - Content header */}
            <div className="content__header">
              <h1>{pathname && (pageNames[pathname] || pageNames[pathname.split('/').slice(0, -1).join('/')])}</h1>
            </div>
            {/* End of - Content header */}
            <DashboardProvider>
              <MessagesProvider>
                {children}
              </MessagesProvider>
            </DashboardProvider>
          </div>
        </div>
      </body>
    </html>
  )
}

const pageLoader = (
  <html lang="en">
    <head />
    <body>
      <div className="loader">
        <div className="dot-pulse"></div>
      </div>
    </body>
  </html>
)