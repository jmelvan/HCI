'use client';

import { useState } from "react";
import { AddButton, Search } from "../../../components/forms";
import Table from "../../../components/table";
import categoriesTableConfig from "./tableConfig";

export default function Categories() {
  const [search, updateSearch] = useState('');

  return (
    <>
      <div className="grid">
        <Search placeholder={`Search Categories...`} value={search} onChange={e => updateSearch(e.currentTarget.value)} />
        <AddButton label="New Category" href='/categories/new' />
      </div>
      <Table model='category' config={categoriesTableConfig} perPage={6} dataURL="/category/admin" search={search} searchMatch="name" />
    </>
  )
}
