'use client';

import CategoryForm from "../../../../components/forms/category-form";

export default function NewCategory() {
  return (
    <CategoryForm />
  )
}