'use client';

import { useEffect, useState } from "react";
import CategoryForm from "../../../../../components/forms/category-form";
import { CategoryScheme } from "../../../../../config/enums/category";
import { getCategory } from "../../../../../helpers/api/categories";

export default function EditCategory({ params: { id } }: { params: { id: number }}) {
  const [category, setCategory] = useState<CategoryScheme | undefined>(undefined);

  useEffect(() => {
    getCategory(id).then(category => setCategory(category));
  }, [])

  if(!category)
    return <></>

  return (
    <CategoryForm {...category} deleteURL="/category/delete/" />
  )
}