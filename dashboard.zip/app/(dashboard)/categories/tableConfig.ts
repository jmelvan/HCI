const categoriesTableConfig = [
  {
    label: 'ID',
    width: '80px',
    match: 'id'
  },
  {
    label: 'Icon',
    width: '100px',
    type: 'img',
    match: 'image'
  },
  {
    label: 'Name Singular',
    width: '160px',
    match: 'name'
  },
  {
    label: 'Name Plural',
    width: 'minmax(200px, auto)',
    match: 'name_plural'
  },
  {
    label: 'Type',
    width: '100px',
    type: 'object',
    objectMatch: 'name',
    match: 'type'
  },
  {
    label: 'Published',
    width: '120px',
    type: 'boolean',
    match: 'is_published'
  },
  {
    label: 'Actions',
    width: '80px',
    type: 'actions',
    edit: '/categories/edit/:id',
    // remove: '/category/delete/:id'
  },
];

export default categoriesTableConfig;