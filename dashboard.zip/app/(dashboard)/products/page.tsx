'use client';

import { useState } from "react";
import FilterSingle from "../../../components/filters/single";
import { AddButton, Search } from "../../../components/forms";
import Table from "../../../components/table";
import productsTableConfig from "./tableConfig";

export default function Categories() {
  const [search, updateSearch] = useState('');
  const [filtersScheme, setFiltersScheme] = useState<Record<any, any>>({});
  const [filters, setFilters] = useState<Record<any, any>>({});

  const loadFilters = (filtersScheme:Record<any, any>) => {
    setFiltersScheme(filtersScheme);
    setFilters(filtersScheme);
  }
  // user action on single filter, update filters state
  const onFilter = (filter:Record<any, any>) => setFilters(prev => ({...prev, [filter.match]: filter}))

  return (
    <>
      <div className="grid">
        {
          Object.values(filtersScheme).map((filter, i) => <FilterSingle key={`filter:${i}`} filter={filter} onFilter={onFilter} span='4' />)
        }
        <AddButton label="New Product" span='4' href="/products/new" />
        <Search placeholder="Search Products..." value={search} onChange={e => updateSearch(e.currentTarget.value)} span='12' />
      </div>
      <Table model='product' config={productsTableConfig} filters={filters} perPage={6} dataURL="/product/admin" search={search} searchMatch="name" getFilters={loadFilters} />
    </>
  )
}
