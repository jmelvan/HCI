'use client';

import { useEffect, useState } from "react";
import ProductForm from "../../../../../components/forms/product-form";
import { ProductScheme } from "../../../../../config/enums/product";
import { getProduct } from "../../../../../helpers/api/products";

export default function EditProduct({ params: { id } }: { params: { id: number }}) {
  const [product, setProduct] = useState<ProductScheme | undefined>(undefined);

  useEffect(() => {
    getProduct(id).then(product => setProduct(product))
  }, [])

  if(!product)
    return <></>

  return (
    <ProductForm {...product} deleteURL="/product/delete/" />
  )
}