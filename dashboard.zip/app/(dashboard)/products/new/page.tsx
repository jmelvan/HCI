'use client';

import ProductForm from "../../../../components/forms/product-form";

export default function NewProduct() {
  return (
    <ProductForm />
  )
}