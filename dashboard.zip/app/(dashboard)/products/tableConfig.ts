const productsTableConfig = [
  {
    label: 'ID',
    width: '80px',
    match: 'id'
  },
  {
    label: 'Image',
    width: '100px',
    type: 'img',
    match: 'image'
  },
  {
    label: 'Name',
    width: 'minmax(200px, auto)',
    match: 'name'
  },
  {
    label: 'Places',
    width: '200px',
    type: 'list',
    objectMatch: 'name',
    match: 'places',
    filter: 'checkbox'
  },
  {
    label: 'Category',
    width: '100px',
    type: 'object',
    objectMatch: 'name',
    match: 'category',
    filter: 'checkbox'
  },
  {
    label: 'Published',
    width: '120px',
    type: 'boolean',
    match: 'is_published'
  },
  {
    label: 'Actions',
    width: '80px',
    type: 'actions',
    edit: '/products/edit/:id',
    // remove: '/product/delete/:id'
  },
];

export default productsTableConfig;