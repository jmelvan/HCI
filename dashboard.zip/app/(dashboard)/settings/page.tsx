import SettingsForm from "../../../components/forms/settings-form";

export default function Categories() {
  return (
    <SettingsForm />
  )
}
