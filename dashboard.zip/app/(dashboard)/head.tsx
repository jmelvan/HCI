import favicon from '../../public/favicon.ico'

export default function Head() {
  return (
    <>
      <title>HCI projekt | Dashboard</title>
      <meta content="width=device-width, initial-scale=1" name="viewport" />
      <meta name="description" content="Dashboard for DigitalMenu application" />
      <link rel="icon" href={favicon.src} />
    </>
  )
}
