'use client';

import PlaceForm from "../../../../components/forms/place-form";

export default function NewPlace() {
  return (
    <PlaceForm />
  )
}