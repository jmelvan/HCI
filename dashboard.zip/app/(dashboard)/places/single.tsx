import Link from "next/link"
import { Image } from "../../../components/image"
import { PlaceSingleScheme } from "../../../config/enums/place"

export default function PlaceSingle(props: PlaceSingleScheme) {
  return (
    <Link href={`/places/edit/${props.slug}`} className="place">
      <div className="place__img">
        <Image src={props.image} />
      </div>
      <h3 className="place__name">{ props.name }</h3>
    </Link>
  )
}