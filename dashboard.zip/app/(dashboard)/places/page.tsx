'use client';

import { useEffect, useState } from "react";
import { AddButton, Search } from "../../../components/forms";
import PlaceSingle from "./single";
import API from '../../../helpers/api';
import { PlaceSingleScheme } from "../../../config/enums/place";

export default function Places() {
  const [search, updateSearch] = useState('');
  const [places, updatePlaces] = useState<PlaceSingleScheme[] | undefined>();
  
  useEffect(() => {
    API.get('/place/admin').then(res => res.data).then(data => updatePlaces(data));
  }, []);

  return (
    <>
      <div className="grid">
        <Search placeholder={`Search Places...`} value={search} onChange={e => updateSearch(e.currentTarget.value)} />
        <AddButton label="New Place" href='/places/new' />
      </div>
      <div className="places grid">
        {
          places && places.map((place, i) => <PlaceSingle key={`place:${i}`} {...place} />)
        }
      </div>
    </>
  )
}