'use client';

import { useEffect, useState } from "react";
import PlaceForm from "../../../../../components/forms/place-form";
import { PlaceSingleScheme } from "../../../../../config/enums/place";
import API from '../../../../../helpers/api';

export default function EditPlace({ params: { slug } }: { params: { slug: string }}) {
  const [place, setPlace] = useState<PlaceSingleScheme | undefined>(undefined);

  useEffect(() => {
    API.get(`/place/${slug}`).then(res => res.data).then(data => setPlace(data));
  }, [])

  if(!place)
    return <></>

  return (
    <PlaceForm {...place} deleteURL="/place/delete/" />
  )
}