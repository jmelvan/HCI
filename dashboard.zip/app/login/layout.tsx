import { Poppins } from '@next/font/google'
import './style.scss'

const poppins = Poppins({
  weight: ['400', '600'],
  subsets: ['latin'],
})

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head />
      <body className={poppins.className}>{children}</body>
    </html>
  )
}
