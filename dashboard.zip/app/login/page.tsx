'use client';

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Input } from "../../components/forms";
import useAuth from "../../hooks/useAuth"
import useForm from "../../hooks/useForm";

export default function Login() {
  const { formData, error, errors, success, handleInput, submit } = useForm({ email: '', password: '' }, ["email", "password"])
  let { setAuth } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if(!success || !success.token) return;
     // if succesfful, store token to local storage
     setAuth(success.token);
     // go to dashboard home
     router.push('/categories');
  }, [success])

  // function to login
  const onLogin = () => submit('/user/login');
  // function to submit login on Enter press
  const submitOnEnter = (e: React.KeyboardEvent<HTMLInputElement>) => e.key === 'Enter' && onLogin()

  return (
    <div className="login-form">
      <h1 className="login-form__h1">Dashboard</h1>
      {
        error && <div className="form-error">{error}</div>
      }
      <Input label="Email" placeholder="Enter your email" value={formData.email} name="email" type="text" onDarkBg onChange={handleInput} onKeyDown={submitOnEnter} error={errors && errors["email"]} />
      <Input label="Password" placeholder="Enter your password" value={formData.password} name="password" type="password" onDarkBg onChange={handleInput} onKeyDown={submitOnEnter} error={errors && errors["password"]} />
      <div className="button--login" onClick={onLogin}>Login</div>
    </div>
  )
}