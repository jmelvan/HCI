export const safeLocalStorage = {
  getItem: (key: string) => typeof window !== 'undefined' && localStorage.getItem(key),
  setItem: (key: string, value: any) => typeof window !== 'undefined' && localStorage.setItem(key, value),
  removeItem: (key: string) => typeof window !== 'undefined' && localStorage.removeItem(key),
};

// functions to get params from url for replacement
// e.g. /categories/edit/:id => ['id']
// used to find placeholders (to prepare replacement with data)
export function getParams(url:string) {
  let last_start = 0;
  let params:string[] = [];
  // loop until the end of the url
  while(last_start < url.length) {
    // get the position of the param begining (starts with ':')
    let start_of_param = url.indexOf(':', last_start);
    // get the position of the param end (ends before '/')
    let end_of_param = url.indexOf('/', start_of_param);
    // extract the param from the url
    let param = url.substring(start_of_param + 1, end_of_param >= 0 ? end_of_param : undefined);
    // store param to returning object
    params.push(param);
    // update last start position
    last_start = end_of_param >= 0 ? end_of_param : url.length;
  }
  // return params
  return params;
}

// function to replace placeholders in url with data from data object
// data mapping (e.g. url="/example/:id" params=['id'] dataObject={id: 3291} => return "/example/3291")
// params match placeholder with field from dataObject
export function replaceParams(url:string, params:string[], dataObject:Record<string, string>) {
  // protection
  if(url.length === 0) return '';
  // replace each param
  for(let param of params)
    url = url.replace(`:${param}`, dataObject[param]);
  return url;
}

// function to force download blob and save it with given filename
export function forceDownload(blob: Blob, filename: string) {
  let URL = window.URL || window.webkitURL || window;
  // create url for blob
  let blobURL = URL.createObjectURL(blob);
  // create temporary <a>
  let downloadLink = document.createElement("a");
  // set blob url as href
  downloadLink.href = blobURL;
  // download filename
  downloadLink.download = filename;
  // append <a> to document
  document.body.appendChild(downloadLink);
  // fake click
  downloadLink.click();
  // remove <a> from document
  document.body.removeChild(downloadLink);
}

// function to format array to object
export function _format(array:any[], lead:string) {
  var formated:any = {};
  // loop through elements
  for(let item of array) 
    formated[item[lead]] = item;
  // return formated object
  return formated;
}

// function to change any value of element inside complex nested arrays (e.g. multiple nested arrays of objects)
export function _update(arr:any[], path:any[], content:any) {
  // removes first element of path and assign to curPos
  let curPos = path.shift();
  // change value at the end of the path and stop recursion (return)
  if(!path.length) return (arr[curPos] = content);
  // create path if it doesn't exist
  if(!arr[curPos]) arr[curPos] = isNaN(parseInt(path[0])) ? {} : [];
  // recursion
  _update(arr[curPos], path, content)
}

// function to prepare array item for delete (add delete property to object inside array if id is proveided. If id is not provided, delete object)
export function _delete(arr:any[], index:string) {
  // clone array
  let temp:any = arr;
  // check if object with that index has id (exists in database)
  // if it exists in database, set delete property to true
  // if id doesn't exist, item is not in database and we can just remove it (no need to send it to API)
  if(temp[index].id)
    temp[index].delete = true;
  else
    temp.splice(index, 1);
  // return temp array
  return temp;
}

export function createFormData(object:any){
  return Object.keys(object).reduce((formData, key) => {
    // check if value is string
    let isString = (typeof object[key] === 'string' || object[key] instanceof String);
    // if image is string - don't send it
    if(key === 'image' && (isString || !object[key])) return formData;
    // if value is not string, JSON stringify it
    let value = (isString || key === 'image') ? object[key] : JSON.stringify(object[key])
    // append form data
    formData.append(key, value);
    // return updated form data
    return formData;
  }, new FormData())
}
