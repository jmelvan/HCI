import API from '.';
import { _format } from '..';

// function to get single category
export const getCategory = async (id:number) => {
  let response = await API.get(`/category/admin/${id}`);
  // format translations
  response.data.translations = _format(response.data.translations, 'language');
  // format attributes translations
  (response.data.attributes as any).map((attribute:any, i:number) => {
    response.data.attributes[i].translations = _format(attribute.translations, 'language');
  })
  // return data
  return response.data;
}