import API from '.';
import { _format } from '..';

interface LoginScheme {
  email: string,
  password: string
}

// function to login
export const login = async (data: LoginScheme) => {
  let response = await API.post(`/user/login`, data);
  return response.data;
}