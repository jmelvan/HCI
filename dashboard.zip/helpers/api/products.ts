import API from '.';
import { _format } from '..';

// function to get single product
export const getProduct = async (id:number) => {
  let response = await API.get(`/product/admin/${id}`);
  // format translations
  response.data.translations = _format(response.data.translations, 'language');
  // format attributes translations
  (response.data.attributes as any).map((attribute:any, i:number) => {
    response.data.attributes[i].translations = _format(attribute.translations, 'language');
  })
  return response.data;
}