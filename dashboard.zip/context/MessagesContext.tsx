import { createContext, useEffect, useState } from "react";
import Message, { MessageScheme } from "../components/messages";
import { _format } from "../helpers";

interface MessagesContextScheme {
  newMessage?: (message: string, status: string) => void,
  removeMessage?: (id: number) => void
}

export const MessagesContext = createContext<MessagesContextScheme>({})

export default function MessagesProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<Record<number, MessageScheme | undefined>>({});

  // function to push new message to queue
  const newMessage = (message: string, status: string) => {
    // random id from 1 to 100
    let id = (Math.random() * 100 ) << 0
    // check if already exists, if it is just bypass this message don't show it
    if(state[id]) return;
    // push new message to state
    setState(prev => ({ ...prev, [id]: { message, status, id, timeout: setTimeout(() => removeMessage(id), 3000) } }))
  }
  // function to remove message after it expires
  const removeMessage = (id: number) => setState(prev => ({ ...prev, [id]: undefined }));

  return (
    <MessagesContext.Provider value={{ newMessage, removeMessage }}>
      <div className="message-container">
        {
          Object.values(state).map(message => message && <Message key={message.id} {...message} />)
        }
      </div>
      { children }
    </MessagesContext.Provider>
  )
}