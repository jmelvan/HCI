import { createContext, useEffect, useState } from "react";
import { CategoryScheme } from "../config/enums/category";
import { PlaceSingleScheme } from "../config/enums/place";
import { TypeScheme } from "../config/enums/type";
import { _format } from "../helpers";
import API from '../helpers/api';

interface DashboardContextScheme {
  places?: PlaceSingleScheme[],
  icons?: { id:number, svg:string }[],
  types?: TypeScheme[],
  categories?: CategoryScheme[]
}

export const DashboardContext = createContext<DashboardContextScheme>({})

// Parallel data fetch and await for all to load
async function fetchContextData() {
  try {
    // initiate all requests in parallel
    let iconsReq = API.get('/icon')
    let placesReq = API.get('/place/admin')
    let typesReq = API.get('/type')
    let categoriesReq = API.get('/category/admin')

    // await for all requests
    const [icons, places, types, categories] = await Promise.all([iconsReq, placesReq, typesReq, categoriesReq])

    // return complete context
    return {
      icons: icons.data,
      places: places.data,
      types: types.data,
      categories: _format(categories.data, "id")
    }
  } catch(e) {
    return {}
  }
}

export default function DashboardProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<DashboardContextScheme>({});

  useEffect(() => {
    fetchContextData().then(setState)
  }, [])

  return (
    <DashboardContext.Provider value={state}>
      { children }
    </DashboardContext.Provider>
  )
}