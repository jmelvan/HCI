import { useEffect, useRef, useState } from "react"
import { _format } from "../../helpers";
import { DropdownIcon } from "../icons";

interface FilterSingleScheme{
  span: string,
  filter: {
    label: string,
    match: string,
    type: string,
    objectMatch?: string,
    items: string[]
  },
  onFilter: (filter: {
    label: string,
    match: string,
    type: string,
    items: string[]
  }) => void
}

export default function FilterSingle(props: FilterSingleScheme) {
  const [list, setList] = useState<string[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [opened, setOpened] = useState(false);
  const ref = useRef<any>(null);

  useEffect(() => {
    setList(props.filter.items.sort())
    // function to be called on outside click
    function handleClickOutside(event: MouseEvent) {
      if(ref.current && !ref.current.contains(event.target))
        setOpened(false)
    }
    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside, false);
    // on component unmount
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside, false);
    };
  }, [])

  // return callback when filter value changes
  useEffect(() => {
    props.onFilter({...props.filter, items: selected.length ? selected : props.filter.items})
  }, [selected])

  // function to toggle item from the list
  const toggle = (e:React.MouseEvent<HTMLElement>) => {
    let item = e.currentTarget.dataset.item!;
    if(selected.includes(item))
      setSelected(prev => prev.filter(s => s !== item))
    else
      setSelected(prev => [...prev, item])
  }

  return (
    <div className={"filter" + (opened ? ' opened' : '') + (props.span ? ` span${props.span}` : '')} ref={ref}>
      <div className="filter__head" onClick={() => setOpened(prev => !prev)}>
        <div className="filter__text">{ selected.length ? selected.join(", ") : props.filter.label }</div>
        <DropdownIcon />
      </div>
      <div className="filter__dropdown">
        <div className="filter__list">
          {
            list.map((item, i) => {
              return <div key={i} className={"filter__checkbox" + (selected.includes(item) ? ' selected' : '')} data-item={item} onClick={toggle}>
                <div className="checkbox"></div>
                <div className="filter__item__text">{item}</div>
              </div>
            })
          }
        </div>
        <div className="filter__clear" onClick={() => selected.length && setSelected([])}>Clear all</div>
      </div>
    </div>
  )
}