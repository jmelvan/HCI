'use client';

import { useRouter } from "next/navigation";
import { useContext, useEffect } from "react";
import Form, { ImageUpload, Input, Select } from ".";
import { ProductScheme } from "../../config/enums/product";
import { DashboardContext } from "../../context/DashboardContext";
import { MessagesContext } from "../../context/MessagesContext";
import useForm from "../../hooks/useForm";
import ProductAttributes from "./parts/product-attributes";
import ProductPrices from "./parts/product-prices";

export default function ProductForm(props: ProductScheme & { deleteURL?: string }) {
  const Router = useRouter();
  // get context data
  const { icons, places, categories } = useContext(DashboardContext);
  const { newMessage } = useContext(MessagesContext);
  // initialize use form hook
  const { 
    formData,
    language,
    errors,
    attributes,
    prices,
    success,
    isDataChanged,
    handleInput,
    handleFileUpload,
    changeLanguage,
    submit,
    handleAttributeInput,
    deleteAttribute,
    addAttribute,
    moveAttribute,
    addNewRepeaterPair,
    deleteRepeaterPair,
    handlePriceInput,
    addPrice,
    deletePrice,
    onPlaceAction,
    onTagAction
  } = useForm<ProductScheme>(props, ["image", "category_id", "places", "tags"]);
  // operation based on given props (create or edit)
  const operation = props.id ? `update/${props.id}` : 'create';
  // boolean is create operation (can be update)
  const isCreate = !props.id;

  // on success form submit
  useEffect(() => {
    // protection
    if(!success) return;
    // push new message
    newMessage && newMessage(`Product successfully ${isCreate ? "created" : "edited"}.`, "success")
    // on update - reload the page, on create - go to edit page
    !isCreate ? setTimeout(() => window.location.reload(), 800) : Router.replace(`/products/edit/${success.id}`)
  }, [success])

  useEffect(() => {console.log(errors);}, [errors])
  
  
  return (
    <Form action={`/product/${operation}`} deleteURL={props.deleteURL} deleteIndex={props.id} isDataChanged={isDataChanged} places={places} selectedPlaces={formData.places} onPlaceAction={onPlaceAction} onSave={submit} onLangChange={changeLanguage}>
      {/* Product image */}
      <ImageUpload label="Product image" name="image" img={formData.image} onFileUpload={handleFileUpload} error="" />
      {/* Product name */}
      <Input label="Product name" name="name" placeholder="Enter product name" value={formData.name || ""} onChange={handleInput} error={errors && errors["name"]} />
      {/* Product category */}
      <Select label="Product category" name="category_id" placeholder="Select product category" value={formData.category_id || ""} options={Object.values(categories || {})} matchText="name" matchValue="id" onChange={handleInput} error={errors && errors["category_id"]}/>
      {/* Category attributes */}
      { 
        formData.category_id && categories && ((categories[formData.category_id]?.attributes?.length || 0) > 0) &&
        <div className="input-wrapper">
          <div className="input-wrapper__label">Product tags</div>
          <div className="product-tags">
            {
              categories[formData.category_id].attributes?.map(({ id, value }) => {
                return <div key={id} className={"product-tag" + (formData.tags?.includes(id || 0) ? " selected" : "")} data-id={id} onClick={onTagAction}>{value}</div>
              })
            }
          </div>
        </div>
      }
      {/* Product prices */}
      <ProductPrices prices={prices} icons={icons} places={places} onChange={handlePriceInput} addNew={addPrice} deleteSingle={deletePrice} errors={errors} />
      {/* Product attributes */}
      <ProductAttributes attributes={attributes} language={language} onChange={handleAttributeInput} addNew={addAttribute} deleteAttribute={deleteAttribute} moveAttribute={moveAttribute} deleteRepeaterPair={deleteRepeaterPair} addNewRepeaterPair={addNewRepeaterPair} errors={errors}/>
  </Form>
  )
}