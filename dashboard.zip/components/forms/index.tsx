import { CheckboxIcon } from "../icons"
import { AddButton } from "./parts/button"
import { Input, Search, ImageUpload, Select, CustomSelect, Textarea } from "./parts/input"
import LanguageSwitcher from "./parts/language-switcher"
import API from '../../helpers/api'

interface FormScheme {
  children: React.ReactNode,
  action?: string,
  places?: Record<string, any>[],
  selectedPlaces?: number[],
  isDataChanged?: boolean,
  deleteURL?: string,
  deleteIndex?: number | string,
  onLangChange?: (lang: string) => void,
  onSave?: (action: string) => void,
  onPlaceAction?: (e: React.FormEvent<HTMLDivElement>) => void
}

export default function Form({ children, action, places, isDataChanged, deleteURL, deleteIndex, selectedPlaces, onSave, onLangChange, onPlaceAction }: FormScheme) {
  
  let deleteItem = async () => {
    try {
      // protection
      if(!deleteURL) return;
      // confirm deleting
      if(!confirm("Are you sure you want to delete this item?")) return;
      // make api call
      await API.delete(deleteURL + deleteIndex);
      // go back
      window.history.back();
    } catch(e) {
      alert("Something went wrong while deleting this item. Please try again later.")
    }
  }
  
  return (
    <div className="grid">
      <div className="form-data">
        { children }
      </div>
      <div className="form-actions">
        {
          onLangChange && <LanguageSwitcher onChange={onLangChange} />
        }
        {
          onSave &&
            <div className="form-box space-top">
              <div className={"button" + (!isDataChanged ? " disabled" : "")} onClick={() => onSave && onSave(action || "")}>Save changes</div>
            </div>
        }
        {
          deleteURL && 
            <div className="form-box space-top">
              <div className={"button--danger"} onClick={deleteItem}>Delete item</div>
            </div>
        }
        {
          places &&
          <div className="form-box space-top">
            <div className="input-wrapper">
              <div className="input-wrapper__label no-padding-top">Shown in places</div>
              <div>
                {
                  places?.map(place => {
                    let selected = selectedPlaces?.includes(place.id) ? "selected" : "";
                    return <div key={place.id} className={`place-box ${selected}`} data-id={place.id} onClick={onPlaceAction}><CheckboxIcon className={selected} />{place.name}</div>
                  })
                }
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  )
}

export { AddButton, Input, Search, ImageUpload, Select, CustomSelect, Textarea }