'use client';

import { useRouter } from "next/navigation";
import { useContext, useEffect } from "react";
import Form, { Input } from ".";
import { MessagesContext } from "../../context/MessagesContext";
import useForm from "../../hooks/useForm";

export default function SettingsForm() {
  const Router = useRouter();
  const { newMessage } = useContext(MessagesContext);
  // initialize use form hook
  const { 
    formData,
    errors,
    error,
    success,
    isDataChanged,
    handleInput,
    submit,
  } = useForm<{password: string, oldPassword: string, passwordConfirm: string}>({password: '', oldPassword: '', passwordConfirm: ''}, ["oldPassword", "password", "passwordConfirm"]);

  // on success form submit
  useEffect(() => {
    // protection
    if(!success) return;
    // push new message
    newMessage && newMessage(`You have successfully changed your data.`, "success")
    // on update - reload the page, on create - go to edit page
    Router.refresh();
  }, [success])
  
  return (
    <Form action={`/user/update`} isDataChanged={isDataChanged} onSave={submit} >
      {
        error && <div className="form-error">{error}</div>
      }
      <Input type="password" label="New password" name="password" placeholder="Enter new password for login ( min. 8 chars )" value={formData.password} onChange={handleInput} error={errors && errors["password"]} />
      <Input type="password" label="Repeat new password" name="passwordConfirm" placeholder="Repeat new password" value={formData.passwordConfirm} onChange={handleInput} error={errors && errors["passwordConfirm"]} />
      <Input type="password" label="Current password" name="oldPassword" placeholder="Enter current password" value={formData.oldPassword} onChange={handleInput} error={errors && errors["oldPassword"]} />
    </Form>
  )
}