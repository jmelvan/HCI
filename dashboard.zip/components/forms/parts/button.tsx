import Link from "next/link"
import addIcon from '../../../public/assets/icons/add.svg'
import addIconLight from '../../../public/assets/icons/add--lightfull.svg'
interface ButtonScheme{
  label: string,
  span?: string,
  href?: string,
  isLightfull?: boolean,
  onClick?: () => void
}

export function AddButton(props: ButtonScheme) {
  if(!props.href)
    if(!props.isLightfull)
      return <div className={"button--add" + (props.span ? ` span${props.span}` : '')} onClick={props.onClick}><img src={addIcon.src} className="button--add__icon" />{props.label}</div>
    else
      return <div className={"button--add lightfull" + (props.span ? ` span${props.span}` : '')} onClick={props.onClick}><img src={addIconLight.src} className="button--add__icon" />{props.label}</div>
  else
    return <Link href={props.href} className={"button--add" + (props.span ? ` span${props.span}` : '')}><img src={addIcon.src} className="button--add__icon" />{props.label}</Link>
}