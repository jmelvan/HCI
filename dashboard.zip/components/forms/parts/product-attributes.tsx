import React, { useEffect, useState } from "react";
import config, { attribute_types, ATTRIBUTE_TYPE_LONG_TEXT, ATTRIBUTE_TYPE_REPEATER, ATTRIBUTE_TYPE_TEXT } from "../../../config";
import { ProductAttributesScheme } from "../../../config/enums/product"
import { AddButton, Input, Select, Textarea } from "../";
import { DropdownIcon, InfoIcon, RemoveIcon } from "../../icons";

interface AttributesScheme {
  attributes: ProductAttributesScheme[],
  language: string,
  errors?: Record<any, any>,
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void,
  addNew?: () => void,
  moveAttribute?: (e: React.FormEvent<HTMLDivElement>) => void,
  deleteAttribute?: (e: React.FormEvent<HTMLDivElement>) => void,
  addNewRepeaterPair?: (attribute_index: number) => void,
  deleteRepeaterPair?: (e: React.FormEvent<HTMLDivElement>) => void
}

export default function ProductAttributes({ attributes, errors, language, onChange, addNew, deleteAttribute, moveAttribute, deleteRepeaterPair, addNewRepeaterPair }: AttributesScheme) {
  // store this check to bypass unneccessary comparisons
  const [isFallbackLanguage, setIsFallbackLanguage] = useState(true);

  useEffect(() => setIsFallbackLanguage(language === config.fallbackLanguage), [language]);

  return(
    <div className="input-wrapper">
      <div className="input-wrapper__label">Product attributes</div>
      <div className="form-box">
        {
          attributes.map(({value, type, translations, ...rest}, i) => {
            // placeholder for label of whole attribute
            let info_label_placeholder = `Enter label for attribute ${i + 1}`
            let info_label = value.key

            // if it's not fallback language, define placeholders
            if(!isFallbackLanguage && translations) {
              info_label_placeholder = `Translate '${value.key}' in ${(config.languagesFlags as any)[language]}[${language}]`;
              info_label = translations[language] && translations[language].value ? translations[language].value.key : ""
            }

            return (
              <div key={i} className={"product-attribute" + (rest.delete ? " shouldDelete" : "")}>
                <div className="product-attribute__info">
                  <Input className="white-bg" value={info_label} name={`${i}/value/key`} label="Label" placeholder={info_label_placeholder} noPaddingTop onChange={onChange} />
                  <Select className="white-bg" value={type} name={`${i}/type`} label="Type" placeholder="Type" options={attribute_types} matchText="label" matchValue="id" noPaddingTop onChange={onChange} />
                  <div className="product-attribute__nav">
                    <div className={"product-attribute__order-action up" + (i === 0 ? " disabled" : "")} data-attribute={i} data-direction="up" onClick={moveAttribute}><DropdownIcon /></div>
                    <div className={"product-attribute__order-action down" + (i === attributes.length - 1 ? " disabled" : "")} data-attribute={i} data-direction="down" onClick={moveAttribute}><DropdownIcon /></div>
                  </div>
                </div>
                {
                  type && 
                  <div className="input-wrapper">
                    <div className="input-wrapper__label">Content</div>
                    <AttributeContent 
                      value={value}
                      type={type}
                      translations={translations}
                      {...rest}
                      index={i}
                      isFallbackLanguage={isFallbackLanguage}
                      language={language}
                      onChange={onChange}
                      deleteRepeaterPair={deleteRepeaterPair}
                      addNewRepeaterPair={addNewRepeaterPair}
                      errors={errors}
                    />
                  </div>
                }
                <div className="remove-complex-attribute" data-index={i} onClick={deleteAttribute}>Remove attribute</div>
              </div>
            )
          })
        }
        <div className="add-attribute">
          <div className="attribute-info"><InfoIcon className="info-icon" />These fields will be shown in the product details</div>
          <AddButton label="New Field" onClick={addNew} />
        </div>
      </div>
    </div>
  )
}

interface AttributeContentScheme extends ProductAttributesScheme {
  isFallbackLanguage: boolean,
  language: string,
  index: number,
  errors?: Record<any, any>,
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void,
  addNewRepeaterPair?: (attribute_index: number) => void,
  deleteRepeaterPair?: (e: React.FormEvent<HTMLDivElement>) => void
}

function AttributeContent({ type, value, translations, isFallbackLanguage, language, index, errors, onChange, deleteRepeaterPair, addNewRepeaterPair }:AttributeContentScheme) {
  console.log(errors)
  if(type == ATTRIBUTE_TYPE_REPEATER) {
    return <>
      {
        value.value.map((item:any, j:number) => {
          let label = item.key
          let value = item.value
          let label_placeholder = `Enter label`
          let value_placeholder = `Enter value`
          
          // if it's not fallback language, translate labels and values
          if(!isFallbackLanguage && translations && translations[language]) {
            label_placeholder = `Translate '${item.key}' in ${(config.languagesFlags as any)[language]}[${language}]`;
            value_placeholder = `Translate '${item.value}' in ${(config.languagesFlags as any)[language]}[${language}]`;
            label = translations[language].value.value && translations[language].value.value[j] ? translations[language].value.value[j].key : "";
            value = translations[language].value.value && translations[language].value.value[j] ? translations[language].value.value[j].value : "";
          }

          return (
            <div key={j} className="repeater__pair">
              <div className="repeater__index">{j + 1}.</div>
              <Input value={label} name={`${index}/value/value/${j}/key`} className="white-bg" placeholder={label_placeholder} onChange={onChange} />
              <Input value={value} name={`${index}/value/value/${j}/value`} className="white-bg" placeholder={value_placeholder} onChange={onChange} error={errors && errors[`attributes.${index}.value.value.${j}.value`]}/>
              <div className="remove-repeater-pair" data-attribute={index} data-pair={j} onClick={deleteRepeaterPair}><RemoveIcon /></div>
            </div>
          )
        })
      }
      <AddButton label="Add more values" onClick={() => addNewRepeaterPair && addNewRepeaterPair(index)} isLightfull />
    </>
  }

  // these below are only for text or textarea (text and long text)
  let info_value_placeholder = `Enter value for attribute ${index + 1}`
  let text_value = value.value[0].value;

  if(!isFallbackLanguage && translations) {
    info_value_placeholder = `Translate '${value.value[0].value}' in ${(config.languagesFlags as any)[language]}[${language}]`
    text_value = translations[language] && translations[language].value.value && translations[language].value.value[0] ? translations[language].value.value[0].value : "";
  }

  if(type == ATTRIBUTE_TYPE_TEXT) {
    return <Input value={text_value} name={`${index}/value/value/0/value`} className="white-bg" placeholder={info_value_placeholder} onChange={onChange} error={errors && errors[`attributes.${index}.value.value.0.value`]}/>
  } else if(type == ATTRIBUTE_TYPE_LONG_TEXT) {
    return <Textarea value={text_value} name={`${index}/value/value/0/value`} className="white-bg" placeholder={info_value_placeholder} onChange={onChange} error={errors && errors[`attributes.${index}.value.value.0.value`]}/>
  }

  // deault... type does'nt exist
  return <></>
}