import { ProductPricesScheme } from "../../../config/enums/product"
import { AddButton, Select, CustomSelect, Input } from "../"
import { RemoveIcon } from "../../icons"

interface PricesScheme {
  prices: ProductPricesScheme[],
  icons?: Record<string, any>[],
  places?: Record<string, any>[],
  errors?: Record<any, any>,
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement >) => void,
  addNew?: () => void,
  deleteSingle?: (e: React.FormEvent<HTMLDivElement>) => void
}

export default function ProductPrices({ prices, icons, places, errors, onChange, addNew, deleteSingle }: PricesScheme) {
  console.log(errors)
  return (
    <div className="input-wrapper">
      <div className="input-wrapper__label">Product prices</div>
      <div className="form-box">
        <div className="prices">
          {
            icons && places &&
            prices.map((price, i) => (
              <div key={i} className={"price-row" + (price.delete ? " shouldDelete" : "")}>
                <CustomSelect className="white-bg" value={price.icon_id} name={`${i}/icon_id`} options={icons} matchText="svg" matchValue="id" onChange={onChange} />
                <div className="price-input size">
                  <Input key={`prices/${i}/size`} className="white-bg" value={price.size} name={`${i}/size`} placeholder="Size" type="text" onChange={onChange} error={errors && errors[`prices.${i}.price`] }/>
                </div>
                <div className="price-input">
                  <Input key={`prices/${i}/price`} className="white-bg" value={price.price} name={`${i}/price`} placeholder="Price" type="text" onChange={onChange} error={errors && errors[`prices.${i}.price`] }/>
                </div>
                <Select className="white-bg" value={price.place_id} name={`${i}/place_id`} placeholder="For place" options={places} matchText="name" matchValue="id" onChange={onChange} error={errors && errors[`prices.${i}.place_id`] }/>
                <div className="remove-price" data-index={i} onClick={deleteSingle}><RemoveIcon /></div>
              </div>
            ))
          }
        </div>
        <AddButton label="Add more prices" onClick={addNew} isLightfull />
      </div>
    </div>
  )
}