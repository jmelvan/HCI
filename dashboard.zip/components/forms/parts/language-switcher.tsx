import React, { useEffect, useState } from "react"
import config from "../../../config";
import { LanguageIcon } from "../../icons"

interface LanguageSwitcherScheme {
  onChange?: (lang: string) => void
}

export default function LanguageSwitcher({ onChange }: LanguageSwitcherScheme) {
  const [language, setLanguage] = useState(config.fallbackLanguage);

  // function to check if language is supported, and return fallback language if not supported
  const getLanguage = (lang: string | undefined) => (lang && config.languages.includes(lang)) ? lang : config.fallbackLanguage;
  // on language click
  const changeLanguage = (e: React.FormEvent<HTMLDivElement>) => setLanguage(getLanguage(e.currentTarget.dataset.lang))
  // return callback when language is changed
  useEffect(() => onChange && onChange(language), [language]);

  return (
    <div className="input-wrapper">
      <div className="input-wrapper__label">Edit for language</div>
      <div className="languages">
        {
          config.languages.map(short => (
            <div key={`lang:${short}`} className={"language" + (short === language ? ' selected' : '')} data-lang={short} onClick={changeLanguage}>
              { LanguageIcon({ language: short }) }
              <div className="language__text">{ short }</div>
            </div>
          ))
        }
      </div>
    </div>
  )
}