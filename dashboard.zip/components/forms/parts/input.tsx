import React, { FormEvent, useEffect, useRef, useState } from "react"
import { _format } from "../../../helpers"
import { SearchIcon, SelectArrowIcon, UploadIcon } from "../../icons"
import { Image } from "../../image"

interface InputScheme {
  label?: string,
  type?: string,
  placeholder?: string,
  name?: string,
  value?: string,
  single?: boolean,
  error?: any,
  defaultValue?: string,
  key?: any,
  onDarkBg?: boolean,
  className?: string,
  noPaddingTop?: boolean,
  onChange?(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>): void,
  onKeyDown?(e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>): void,
  span?: string
}

interface SelectScheme {
  label?: string,
  name?: string,
  options?: Record<string, any>[],
  matchValue: string,
  matchText: string,
  value?: string | number,
  placeholder?: string,
  error?: any,
  className?: string,
  noPaddingTop?: boolean,
  onChange?(e: React.ChangeEvent<HTMLSelectElement>): void,
}

interface UploadProps {
  img?: any, 
  name?: string,
  label?: string,
  error?: string,
  onFileUpload?: (file: File, name: string) => void,
}

export function Input(props: InputScheme) {
  return (
    <div className={"input-wrapper" + (props.onDarkBg ? " dark-bg" : "") + (props.error ? " error" : "")}>
      {props.label && <div className={"input-wrapper__label" + (props.noPaddingTop ? " no-padding-top" : "")}>{props.label}</div>}
      <input className={props.className} key={props.key} defaultValue={props.defaultValue} name={props.name} value={props.value} type={props.type} placeholder={props.placeholder} onChange={props.onChange} onKeyDown={props.onKeyDown} />
      {
        props.error && ((props.error.rule !== 'required') ? <div className="input-error">{props.error.message}</div> : (props.value?.length === 0 && <div className="input-error">{props.error.message}</div>))
      }
    </div>
  )
}

export function Textarea(props: InputScheme) {
  return (
    <div className={"input-wrapper" + (props.onDarkBg ? " dark-bg" : "") + (props.error ? " error" : "")}>
      <div className={"input-wrapper__label" + (props.noPaddingTop ? " no-padding-top" : "")}>{props.label}</div>
      <textarea className={props.className} key={props.key} defaultValue={props.defaultValue} name={props.name} value={props.value} placeholder={props.placeholder} onChange={props.onChange} onKeyDown={props.onKeyDown}></textarea>
    </div>
  )
}

export function Select(props: SelectScheme) {
  return (
    <div className={"input-wrapper" + (props.error ? " error" : "")}>
      {props.label && <div className={"input-wrapper__label" + (props.noPaddingTop ? " no-padding-top" : "")}>{props.label}</div>}
      <div className="select-wrapper">
        <div className="select-arrow"><SelectArrowIcon /></div>
        <select className={props.className} name={props.name} onChange={props.onChange} required>
          {
            props.placeholder && <option value="" selected={!props.value} disabled>{ props.placeholder }</option>
          }
          {
            props.options &&
            props.options?.map(option => {
              let value = option[props.matchValue || 0];
              let text = props.matchText && option[props.matchText]
              return <option key={`option:${value}`} value={value} selected={props.value == value}>{ text }</option>
            })
          }
        </select>
      </div>
      {
        props.error && <div className="input-error">{props.error.message}</div>
      }
    </div>
  )
}

export function Search(props: InputScheme) {
  return (
    <div className={"search" + (props.span ? ` span${props.span}` : '')}>
      <SearchIcon className="search__icon" />
      <input key={props.key} defaultValue={props.defaultValue} name={props.name} value={props.value} type={props.type} placeholder={props.placeholder} onChange={props.onChange} onKeyDown={props.onKeyDown} />
    </div>
  )
}

export const ImageUpload = (props: UploadProps) => {
  const ImageRef = useRef<HTMLInputElement>(null);
  const [uploadedImg, setUploadedImg] = useState<string | undefined>(undefined);
  // on first load, show image if is already uploaded
  useEffect(() => setUploadedImg(props.img), [])

  // function called on file upload to show uploaded image
  const handleFileUpload = (e: FormEvent<HTMLInputElement>) => {
    const file = e.currentTarget.files![0];
    // protection
    if(!file) return
    // show image
    setUploadedImg(URL.createObjectURL(file));
    // return file to main component 
    props.onFileUpload && props.onFileUpload(file, props.name || 'default');
  }

  return (
    <div className="input-wrapper">
      <div className="input-wrapper__label">{props.label}</div>
      <div className="banner-wrapper">
        <div className={"banner hover--opacity" + (uploadedImg ? " uploaded" : "")} data-invalid={props.error !== '' && !uploadedImg}>
          {
            uploadedImg && <Image src={uploadedImg} fadeIn className="contain" />
          }
          <div className="banner__upload-icon" onClick={() => { ImageRef.current!.click(); }}>
            <UploadIcon />
            <input ref={ImageRef} type="file" accept="image/*" name={props.name} onInput={handleFileUpload} style={{display: 'none'}} />
          </div>
        </div>
      </div>
    </div>
  );
}

export function CustomSelect(props: SelectScheme) {
  const [selected, setSelected] = useState<any>(props.value)
  const [options, setOptions] = useState<any>(undefined)
  const [dropdown, toggleDropdown] = useState(false);
  const ref = useRef<any>(null);

  // prepare options to display (format array to object)
  useEffect(() => {
    // protection
    if(!props.options) return
    // change options from array to object for easier mapping
    setOptions(_format(props.options, props.matchValue))
    // if value is not defined (e.g. creating new product/price) select first value from options
    !props.value && setSelected(props.options[0][props.matchValue])
    // function to be called on outside click
    function handleClickOutside(event: MouseEvent) {
      if(ref.current && !ref.current.contains(event.target))
        toggleDropdown(false)
    }
    // Bind the event listener
    document.addEventListener("mousedown", handleClickOutside, false);
    // on component unmount
    return () => {
      // Unbind the event listener on clean up
      document.removeEventListener("mousedown", handleClickOutside, false);
    };
  }, [])
  // return on change event when new item is selected
  useEffect(() => {props.onChange && props.onChange({ target: { name: props.name, value: selected } } as React.ChangeEvent<HTMLSelectElement>)}, [selected])
  // store selected value
  const select = (e: React.FormEvent<HTMLDivElement>) => setSelected(e.currentTarget.dataset.value)

  return (
    <div className={"select-wrapper" + (props.error ? " error" : "")} ref={ref}>
      <div className="cusotom-select-arrow"><SelectArrowIcon /></div>
      <div className={"custom-select" + ` ${props.className}`} onClick={() => toggleDropdown(prev => !prev)}>
        <div className="custom-select__value"><img src={selected && options && `data:image/svg+xml;utf8,${encodeURIComponent(options[selected][props.matchText])}`} /></div>
        <div className={"custom-select__dropdown" + (dropdown ? " opened" : "")}>
          {
            props.options?.map(option => {
              let text = option[props.matchText || 0];
              let value = option[props.matchValue || 0];
              return <div key={`cs:${value}`} className={"custom-select__option" + (value == selected ? " selected" : "")} data-value={value} onClick={select}><img src={`data:image/svg+xml;utf8,${encodeURIComponent(text)}`} /></div>
            })
          }
        </div>
      </div>
      {
        props.error && <div className="input-error">{props.error.message}</div>
      }
    </div>
  )
}