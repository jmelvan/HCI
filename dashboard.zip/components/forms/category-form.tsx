'use client';

import { useRouter } from "next/navigation";
import { useContext, useEffect, useState } from "react";
import Form, { AddButton, ImageUpload, Input, Select } from ".";
import config from "../../config";
import { CategoryScheme } from "../../config/enums/category";
import { DashboardContext } from "../../context/DashboardContext";
import { MessagesContext } from "../../context/MessagesContext";
import useForm from "../../hooks/useForm";
import { InfoIcon, RemoveIcon } from "../icons";

export default function CategoryForm(props: CategoryScheme & { deleteURL?: string }) {
  const Router = useRouter();
  // get context data
  const { types } = useContext(DashboardContext);
  const { newMessage } = useContext(MessagesContext);
  // initialize use form hook
  const { 
    formData, language, attributes, error, errors, success, isDataChanged, handleInput, handleFileUpload, changeLanguage, submit, handleAttributeInput, deleteAttribute, addAttribute
  } = useForm<CategoryScheme>(props, ["image", "type_id"])
  // store this check to bypass unneccessary comparisons
  const [isFallbackLanguage, setIsFallbackLanguage] = useState(true);
  // operation based on given props (create or edit)
  const operation = props.id ? `update/${props.id}` : 'create';
  // boolean is create operation (can be update)
  const isCreate = !props.id;
  
  // on lanugage change update fallback language status
  useEffect(() => setIsFallbackLanguage(language === config.fallbackLanguage), [language]);
  // on success form submit
  useEffect(() => {
    // protection
    if(!success) return;
    // push new message
    newMessage && newMessage(`Category successfully ${isCreate ? "created" : "edited"}.`, "success")
    // on update - reload the page, on create - go to edit page
    !isCreate ? setTimeout(() => window.location.reload(), 800) : Router.replace(`/categories/edit/${success.id}`)
  }, [success])


  return (
    <Form isDataChanged={isDataChanged} deleteURL={props.deleteURL} deleteIndex={props.id} action={`/category/${operation}`} onSave={submit} onLangChange={changeLanguage}>
      <ImageUpload label="Category image" name="image" img={formData.image || ""} onFileUpload={handleFileUpload} error="" />
      <Input label="Category name - plural" name="name_plural" placeholder="Enter category name plural" value={formData.name_plural || ""} onChange={handleInput} error={errors && errors["name_plural"]} />
      <Input label="Category name - singular" name="name" placeholder="Enter category name singular" value={formData.name || ""} onChange={handleInput} error={errors && errors["name"]} />
      <Select label="Category type" name="type_id" placeholder="Select category type" value={formData.type_id || ""} options={types} matchText="name" matchValue="id" onChange={handleInput} error={errors && errors["type_id"]} />
      <div className="input-wrapper">
        <div className="input-wrapper__label">Category attributes for product</div>
        <div className="form-box">
          {
            attributes.map((attribute, i) =>{
              let value = isFallbackLanguage ? attribute.value : (attribute.translations[language] ? attribute.translations[language].value : "")
              let placeholder = attribute.translations && !isFallbackLanguage ? `Translate '${attribute.value}' in ${(config.languagesFlags as any)[language]}[${language}]` : `Enter value for attribute ${i + 1}`
              return (
                <div key={i} className={"attribute" + (attribute.delete ? " shouldDelete" : "")}>
                  <Input key={`attribute:${i}`} className="white-bg" value={value} name={`${i}/value`} type="text" placeholder={placeholder} onChange={handleAttributeInput} error={errors && errors[`attributes.${i}.value`]} />
                  <div className="remove-attribute" data-index={i} onClick={deleteAttribute}><RemoveIcon /></div>
                </div>
              )
            })
          }
          <div className="add-attribute">
            <div className="attribute-info"><InfoIcon className="info-icon" />These attributes can be assigned to product with this category</div>
            <AddButton label="New Attribute" onClick={() =>  addAttribute(true)} />
          </div>
        </div>
      </div>
    </Form>
  )
}