'use client';

import { useContext, useEffect, useMemo, useRef, useState } from "react";
import QRCode from 'react-qr-code';
import { forceDownload } from "../../helpers";
import Form, { ImageUpload, Input } from ".";
import useForm from "../../hooks/useForm";
import { useRouter } from "next/navigation";
import { MessagesContext } from "../../context/MessagesContext";

interface PlaceScheme {
  id?: number,
  name?: string,
  slug?: string,
  image?: File | string
}

export default function PlaceForm(props: PlaceScheme & { deleteURL?: string }) {
  const Router = useRouter();
  // use message context
  const { newMessage } = useContext(MessagesContext);
  // initialize use form hook
  const { formData, error, errors, success, isDataChanged, handleInput, handleFileUpload, submit } = useForm<PlaceScheme>(props)
  // operation based on given props (create or edit)
  const operation = props.id ? `update/${props.slug}` : 'create';
  // boolean is create operation (can be update)
  const isCreate = !props.id;

  // cache QR code (we don't want re-rendering on QR code because it slows down everything, especially keyboard inputs)
  const QRCode = useMemo(() => <PlaceQRCode slug={formData.slug} />, []);
  // on success form submit
  useEffect(() => {
    // protection
    if(!success) return;
    // push new message
    newMessage && newMessage(`Place successfully ${isCreate ? "created" : "edited"}.`, "success")
    console.log(success);
    // on update - reload the page, on create - go to edit page
    !isCreate && props.slug === success.slug ? Router.refresh() : Router.replace(`/places/edit/${success.slug}`)
  }, [success])
  
  return (
    <Form isDataChanged={isDataChanged} deleteURL={props.deleteURL} deleteIndex={props.slug} action={`/place/${operation}`} onSave={submit}>
      <ImageUpload label="Place image" name="image" img={formData.image} onFileUpload={handleFileUpload} error={errors && errors["image"]} />
      <Input label="Place name" name="name" placeholder="Enter place name" value={formData.name} onChange={handleInput} error={errors && errors["name"]} />
      <Input label="Place slug" name="slug" placeholder="Enter place slug" value={formData.slug} onChange={handleInput} error={errors && errors["slug"]} />
      { QRCode }
    </Form>
  )
}

function PlaceQRCode(props: { slug?: string }) {
  const qrcodeBox = useRef<HTMLDivElement>(null);
  const [QRcodeLoaded, setQRcodeLoaded] = useState(false);

  useEffect(() => setQRcodeLoaded(true), [qrcodeBox.current])

  // function to download place QR code
  const downloadQRcode = () => {
    // get qr code svg from document with query selector
    let qrCode = document.querySelector('.qrcode-wrapper > svg')?.outerHTML;
    // protection
    if(!qrCode) return;
    // create blob from element
    let blob = new Blob([qrCode], { type:'image/svg+xml;charset=utf-8' });
    // force download
    forceDownload(blob, `${props.slug}.svg`)
  }

  return (
    <div className="qr-code input-wrapper">
      <div className="input-wrapper__label">Place QR code</div>
      <div className="qrcode-wrapper" ref={qrcodeBox}>
        {
          QRcodeLoaded && 
          <QRCode style={{ height: "auto", maxWidth: "100%", width: "100%" }} size={qrcodeBox.current ? (qrcodeBox.current.clientWidth - 40) : 256} value={props.slug || ''} />
        }
      </div>
      <div className="button" onClick={downloadQRcode}>Download QR code</div>
    </div>
  )
}