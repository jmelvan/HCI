'use client';

import Link from 'next/link';
import { navigation } from '../../config/navigation';
import { useRouter, useSelectedLayoutSegment } from 'next/navigation';
import { LogoutIcon } from '../icons';
import logo from '../../public/assets/logo.svg'
import useAuth from '../../hooks/useAuth';

interface SidebarScheme {
  toggle: () => void
}

export default function Sidebar(props: SidebarScheme) {
  const { removeAuth } = useAuth();
  const Router = useRouter();
  const segment = useSelectedLayoutSegment();

  const logout = () => {
    // remove token from storage
    removeAuth();
    // refresh the site
    Router.replace('/login');
  }

  return (
    <div className="sidebar">
      <div className="menu-trigger" onClick={props.toggle}><div className="hamburger"></div></div>
      <div>
        {/* Sidebar logo */}
        <div className="sidebar__logo">
          <img src={logo.src} alt={'logo'} />
        </div>
        {/* Sidebar navigation */}
        <div className="sidebar__nav">
          {
            navigation.map((group, i) => (
              <div key={`nav-group__${i}`} className="sidebar__nav-group">
                <div className="sidebar__nav-group__label">{group.label}</div>
                { 
                  group.items.map(({icon, label, slug}, j) => {
                    // get active layout (used to display active route)
                    const isActive = slug === segment;
                    // return nav item
                    return <Link key={`nav-item__${i}-${j}`} href={`/${slug}`}>
                      <div className={"sidebar__nav-item" + (isActive ? " active" : "")}>{icon}{label}</div>
                    </Link>
                  }) 
                }
              </div>
            ))
          }
        </div>
      </div>
      {/* Logout button */}
      <div className='logout' onClick={logout}><LogoutIcon className="sidebar__nav-item__icon" />Logout</div>
    </div>
  )
}