import { useState } from "react";
import config from "../../config";

interface ImageProps {
  src: string,
  alt?: string,
  isSvg?: boolean,
  fadeIn?: boolean,
  className?: string
}

export const Image = (props: ImageProps) => {
  const [loaded, setLoaded] = useState(false);

  const onLoad = () => {
    setLoaded(true);
  }

  const isBlob = props.src ? (props.src.split(':'))[0] === 'blob' : false;
  const src = isBlob ? props.src : (config.assets + props.src)

  if(props.isSvg)
    return <img className={props.className || ""} src={src} alt={props.alt}/>

  return (
    <picture className={(props.className || "") + (loaded ? " loaded" : "")}>
      <img className={(props.fadeIn ? " fadeIn" : "")} src={src} alt={props.alt} loading='lazy' onLoad={onLoad}/>
    </picture>
  )
}