import { LanguageIcon } from "./languages"

export interface IconsScheme {
  className?: string
}

export const CategoriesIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_289_107)">
    <path d="M7.49992 3.33301H4.16659C3.70635 3.33301 3.33325 3.7061 3.33325 4.16634V7.49967C3.33325 7.95991 3.70635 8.33301 4.16659 8.33301H7.49992C7.96016 8.33301 8.33325 7.95991 8.33325 7.49967V4.16634C8.33325 3.7061 7.96016 3.33301 7.49992 3.33301Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15.8334 3.33301H12.5001C12.0398 3.33301 11.6667 3.7061 11.6667 4.16634V7.49967C11.6667 7.95991 12.0398 8.33301 12.5001 8.33301H15.8334C16.2937 8.33301 16.6667 7.95991 16.6667 7.49967V4.16634C16.6667 3.7061 16.2937 3.33301 15.8334 3.33301Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.49992 11.667H4.16659C3.70635 11.667 3.33325 12.0401 3.33325 12.5003V15.8337C3.33325 16.2939 3.70635 16.667 4.16659 16.667H7.49992C7.96016 16.667 8.33325 16.2939 8.33325 15.8337V12.5003C8.33325 12.0401 7.96016 11.667 7.49992 11.667Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15.8334 11.667H12.5001C12.0398 11.667 11.6667 12.0401 11.6667 12.5003V15.8337C11.6667 16.2939 12.0398 16.667 12.5001 16.667H15.8334C16.2937 16.667 16.6667 16.2939 16.6667 15.8337V12.5003C16.6667 12.0401 16.2937 11.667 15.8334 11.667Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_289_107">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const ProductsIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_289_131)">
    <path d="M4.99992 17.5003C5.92039 17.5003 6.66659 16.7541 6.66659 15.8337C6.66659 14.9132 5.92039 14.167 4.99992 14.167C4.07944 14.167 3.33325 14.9132 3.33325 15.8337C3.33325 16.7541 4.07944 17.5003 4.99992 17.5003Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14.1667 17.5003C15.0871 17.5003 15.8333 16.7541 15.8333 15.8337C15.8333 14.9132 15.0871 14.167 14.1667 14.167C13.2462 14.167 12.5 14.9132 12.5 15.8337C12.5 16.7541 13.2462 17.5003 14.1667 17.5003Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14.1666 14.1667H4.99992V2.5H3.33325" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M5 4.16699L16.6667 5.00033L15.8333 10.8337H5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_289_131">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const PlacesIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_294_1399)">
    <path d="M2.5 17.5H17.5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M4.16675 17.5V5.83333L10.8334 2.5V17.5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15.8333 17.4997V9.16634L10.8333 5.83301" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 7.5V7.50833" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 10V10.0083" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 12.5V12.5083" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 15V15.0083" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_294_1399">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const SettingsIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_294_1410)">
    <path d="M8.60417 3.5975C8.95917 2.13417 11.0408 2.13417 11.3958 3.5975C11.4491 3.81733 11.5535 4.02148 11.7006 4.19333C11.8477 4.36518 12.0332 4.49988 12.2422 4.58645C12.4512 4.67303 12.6776 4.70904 12.9032 4.69156C13.1287 4.67407 13.3469 4.60359 13.54 4.48583C14.8258 3.7025 16.2983 5.17417 15.515 6.46083C15.3974 6.65388 15.327 6.87195 15.3096 7.09731C15.2922 7.32267 15.3281 7.54897 15.4146 7.75782C15.5011 7.96666 15.6356 8.15215 15.8073 8.29921C15.9789 8.44627 16.1829 8.55075 16.4025 8.60417C17.8658 8.95917 17.8658 11.0408 16.4025 11.3958C16.1827 11.4491 15.9785 11.5535 15.8067 11.7006C15.6348 11.8477 15.5001 12.0332 15.4135 12.2422C15.327 12.4512 15.291 12.6776 15.3084 12.9032C15.3259 13.1287 15.3964 13.3469 15.5142 13.54C16.2975 14.8258 14.8258 16.2983 13.5392 15.515C13.3461 15.3974 13.1281 15.327 12.9027 15.3096C12.6773 15.2922 12.451 15.3281 12.2422 15.4146C12.0333 15.5011 11.8479 15.6356 11.7008 15.8073C11.5537 15.9789 11.4492 16.1829 11.3958 16.4025C11.0408 17.8658 8.95917 17.8658 8.60417 16.4025C8.5509 16.1827 8.44648 15.9785 8.29941 15.8067C8.15233 15.6348 7.96676 15.5001 7.75779 15.4135C7.54882 15.327 7.32236 15.291 7.09685 15.3084C6.87133 15.3259 6.65313 15.3964 6.46 15.5142C5.17417 16.2975 3.70167 14.8258 4.485 13.5392C4.60258 13.3461 4.67296 13.1281 4.6904 12.9027C4.70785 12.6773 4.67187 12.451 4.58539 12.2422C4.49892 12.0333 4.36438 11.8479 4.19273 11.7008C4.02107 11.5537 3.81714 11.4492 3.5975 11.3958C2.13417 11.0408 2.13417 8.95917 3.5975 8.60417C3.81733 8.5509 4.02148 8.44648 4.19333 8.29941C4.36518 8.15233 4.49988 7.96676 4.58645 7.75779C4.67303 7.54882 4.70904 7.32236 4.69156 7.09685C4.67407 6.87133 4.60359 6.65313 4.48583 6.46C3.7025 5.17417 5.17417 3.70167 6.46083 4.485C7.29417 4.99167 8.37417 4.54333 8.60417 3.5975Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M10 12.5C11.3807 12.5 12.5 11.3807 12.5 10C12.5 8.61929 11.3807 7.5 10 7.5C8.61929 7.5 7.5 8.61929 7.5 10C7.5 11.3807 8.61929 12.5 10 12.5Z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_294_1410">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const DeleteIcon = (props: IconsScheme) => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_289_370)">
    <path d="M3.33325 5.83301H16.6666" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8.33325 9.16699V14.167" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M11.6667 9.16699V14.167" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M4.16675 5.83301L5.00008 15.833C5.00008 16.275 5.17568 16.699 5.48824 17.0115C5.8008 17.3241 6.22472 17.4997 6.66675 17.4997H13.3334C13.7754 17.4997 14.1994 17.3241 14.5119 17.0115C14.8245 16.699 15.0001 16.275 15.0001 15.833L15.8334 5.83301" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 5.83333V3.33333C7.5 3.11232 7.5878 2.90036 7.74408 2.74408C7.90036 2.5878 8.11232 2.5 8.33333 2.5H11.6667C11.8877 2.5 12.0996 2.5878 12.2559 2.74408C12.4122 2.90036 12.5 3.11232 12.5 3.33333V5.83333" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_289_370">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const EditIcon = (props: IconsScheme) => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_289_365)">
    <path d="M7.49992 5.83301H4.99992C4.55789 5.83301 4.13397 6.0086 3.82141 6.32116C3.50885 6.63372 3.33325 7.05765 3.33325 7.49967V14.9997C3.33325 15.4417 3.50885 15.8656 3.82141 16.1782C4.13397 16.4907 4.55789 16.6663 4.99992 16.6663H12.4999C12.9419 16.6663 13.3659 16.4907 13.6784 16.1782C13.991 15.8656 14.1666 15.4417 14.1666 14.9997V12.4997" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 12.4995H10L17.0833 5.4162C17.4149 5.08468 17.6011 4.63505 17.6011 4.1662C17.6011 3.69736 17.4149 3.24773 17.0833 2.9162C16.7518 2.58468 16.3022 2.39844 15.8333 2.39844C15.3645 2.39844 14.9149 2.58468 14.5833 2.9162L7.5 9.99954V12.4995Z" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M13.3333 4.16699L15.8333 6.66699" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_289_365">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const NavArrowIcon = (props: IconsScheme) => (
  <svg className={props.className} width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_289_663)">
    <path d="M10 4L6 8L10 12" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_289_663">
    <rect width="16" height="16" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const SearchIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_293_71)">
    <path d="M8.33333 14.1667C11.555 14.1667 14.1667 11.555 14.1667 8.33333C14.1667 5.11167 11.555 2.5 8.33333 2.5C5.11167 2.5 2.5 5.11167 2.5 8.33333C2.5 11.555 5.11167 14.1667 8.33333 14.1667Z" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M17.5 17.5L12.5 12.5" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_293_71">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const DropdownIcon = (props: IconsScheme) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_293_445)">
    <path d="M12 6L8 10L4 6" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_293_445">
    <rect width="16" height="16" fill="white" transform="matrix(0 -1 -1 0 16 16)"/>
    </clipPath>
    </defs>
  </svg>
)

export const UploadIcon = (props: IconsScheme) => (
  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5 21.25V23.75C5 24.413 5.26339 25.0489 5.73223 25.5178C6.20107 25.9866 6.83696 26.25 7.5 26.25H22.5C23.163 26.25 23.7989 25.9866 24.2678 25.5178C24.7366 25.0489 25 24.413 25 23.75V21.25" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8.75 11.25L15 5L21.25 11.25" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15 5V20" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

export const SelectArrowIcon = (props: IconsScheme) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_296_1485)">
    <path d="M12 6L8 10L4 6" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_296_1485">
    <rect width="16" height="16" fill="white" transform="matrix(0 -1 -1 0 16 16)"/>
    </clipPath>
    </defs>
  </svg>
)

export const RemoveIcon = (props: IconsScheme) => (
  <svg className={props.className} width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_416_200)">
    <path d="M22.5 7.5L7.5 22.5" stroke="#A84552" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 7.5L22.5 22.5" stroke="#A84552" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_416_200">
    <rect width="30" height="30" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const InfoIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_296_1580)">
    <path d="M10 17.5C14.1421 17.5 17.5 14.1421 17.5 10C17.5 5.85786 14.1421 2.5 10 2.5C5.85786 2.5 2.5 5.85786 2.5 10C2.5 14.1421 5.85786 17.5 10 17.5Z" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M10 6.66699H10.0083" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M9.16675 10H10.0001V13.3333H10.8334" stroke="#6A6F79" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_296_1580">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const GlassIcon = (props: IconsScheme) => (
  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 27.75H18" stroke="#12151C" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15 23.25V27.75" stroke="#12151C" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M18.75 14.25L19.5 19.5C19.5 21.759 17.4855 23.25 15 23.25C12.5145 23.25 10.5 21.759 10.5 19.5L11.25 14.25H18.75Z" fill="#12151C" stroke="#12151C" strokeWidth="0.9" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

export const SmallBottleIcon = (props: IconsScheme) => (
  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13.8569 16.3807H16.185V11.841C16.185 11.6558 16.1237 11.4781 16.0145 11.3471C15.9054 11.2162 15.7573 11.1426 15.603 11.1426H14.4389C14.2846 11.1426 14.1365 11.2162 14.0274 11.3471C13.9183 11.4781 13.8569 11.6558 13.8569 11.841V16.3807Z" fill="#12151C" stroke="#12151C" strokeWidth="0.825" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16.1854 15.6826C16.1854 16.8182 16.4805 17.9259 17.0293 18.8513L17.0584 18.9002C17.6263 19.8575 17.9315 21.0034 17.9314 22.1786V26.508C17.9314 26.8785 17.8088 27.2338 17.5905 27.4957C17.3722 27.7577 17.0761 27.9048 16.7674 27.9048H13.2753C12.9666 27.9048 12.6706 27.7577 12.4523 27.4957C12.234 27.2338 12.1113 26.8785 12.1113 26.508V22.1779C12.1113 21.0031 12.4163 19.8577 12.9843 18.9002L13.0134 18.8513C13.5624 17.926 13.8574 16.8184 13.8574 15.6826H16.1854Z" fill="#12151C" stroke="#12151C" strokeWidth="0.825" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

export const BigBottleIcon = (props: IconsScheme) => (
  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13.5884 12.428H16.7256V6.23754C16.7256 5.98495 16.643 5.74271 16.4959 5.5641C16.3488 5.3855 16.1493 5.28516 15.9413 5.28516H14.3727C14.1647 5.28516 13.9652 5.3855 13.8181 5.5641C13.671 5.74271 13.5884 5.98495 13.5884 6.23754V12.428Z" fill="#12151C"/>
    <path d="M16.7255 11.4756C16.7255 13.0242 17.1232 14.5346 17.8628 15.7965L17.902 15.8632C18.6673 17.1686 19.0786 18.7313 19.0785 20.3337V26.2375C19.0785 26.7427 18.9132 27.2271 18.619 27.5844C18.3249 27.9416 17.9259 28.1423 17.5099 28.1423H12.804C12.388 28.1423 11.989 27.9416 11.6948 27.5844C11.4006 27.2271 11.2354 26.7427 11.2354 26.2375V20.3327C11.2354 18.7308 11.6463 17.1689 12.4118 15.8632L12.451 15.7965C13.1908 14.5348 13.5883 13.0244 13.5883 11.4756H16.7255Z" fill="#12151C"/>
  </svg>
)

export const CheckboxIcon = (props: IconsScheme) => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#clip0_298_179)">
      {
        props.className === "selected" ? <>
          <path d="M13.5 3H4.5C3.67157 3 3 3.67157 3 4.5V13.5C3 14.3284 3.67157 15 4.5 15H13.5C14.3284 15 15 14.3284 15 13.5V4.5C15 3.67157 14.3284 3 13.5 3Z" stroke="#12151C" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M6.75 9L8.25 10.5L11.25 7.5" stroke="#12151C" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
        </>
        :
          <path d="M13.5 3H4.5C3.67157 3 3 3.67157 3 4.5V13.5C3 14.3284 3.67157 15 4.5 15H13.5C14.3284 15 15 14.3284 15 13.5V4.5C15 3.67157 14.3284 3 13.5 3Z" stroke="#F2F2F2" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      }
    </g>
    <defs>
    <clipPath id="clip0_298_179">
    <rect width="18" height="18" fill="white"/>
    </clipPath>
    </defs>
  </svg>
)

export const DeleteMessageIcon = (props: IconsScheme) => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M15 5L5 15" stroke="#C2C2C2" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M5 5L15 15" stroke="#C2C2C2" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

export const LogoutIcon = (props: IconsScheme) => (
  <svg className={props.className} width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_298_357)">
    <path d="M11.6667 6.66634V4.99967C11.6667 4.55765 11.4911 4.13372 11.1785 3.82116C10.866 3.5086 10.442 3.33301 10 3.33301H4.16667C3.72464 3.33301 3.30072 3.5086 2.98816 3.82116C2.67559 4.13372 2.5 4.55765 2.5 4.99967V14.9997C2.5 15.4417 2.67559 15.8656 2.98816 16.1782C3.30072 16.4907 3.72464 16.6663 4.16667 16.6663H10C10.442 16.6663 10.866 16.4907 11.1785 16.1782C11.4911 15.8656 11.6667 15.4417 11.6667 14.9997V13.333" stroke="#A33847" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5.8335 10H17.5002L15.0002 7.5M15.0002 12.5L17.5002 10" stroke="#A33847" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <defs>
    <clipPath id="clip0_298_357">
    <rect width="20" height="20" fill="white"/>
    </clipPath>
    </defs>
  </svg>
);

export { LanguageIcon }