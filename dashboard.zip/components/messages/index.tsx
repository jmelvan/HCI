import { useContext } from 'react';
import { MessagesContext } from '../../context/MessagesContext';
import { DeleteMessageIcon } from '../icons';

export interface MessageScheme {
  id: number,
  message: string,
  status: string
}

const Message = (props: MessageScheme) => {
  const { removeMessage } = useContext(MessagesContext)

  return (
    <div className={'message ' + props.status}>
      <div className='message__data'>
        {/* <MessageIcon type={props.type} /> */}
        <div className='message__text'>{ props.message }</div>
      </div>
      <div className='message__remove' onClick={() => removeMessage && removeMessage(props.id)}>
        <DeleteMessageIcon />
      </div>
    </div>
  )
}

export default Message;