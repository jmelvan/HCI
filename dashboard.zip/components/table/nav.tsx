import { useEffect, useState } from "react";
import { NavArrowIcon } from "../icons";

interface TableNavScheme {
  items: number,
  perPage: number,
  page: number,
  isDataLoading: boolean,
  onAction: (action:number) => void,
  jump: (page:number) => void
}

export default function TableNav(props: TableNavScheme) {
  const [pages, setPages] = useState(Math.ceil(props.items / props.perPage));

  useEffect(() => {
    setPages(Math.ceil(props.items / props.perPage))
  }, [props.items])

  if(props.isDataLoading)
    return <></>

  return (
    <div className="table__nav">
      <div className="table__nav__content">
        {/* Showing info (e.g. 1-6 of 12 items ) */}
        <div className="table__nav__showing">{ getShowingInfo(props.page, props.perPage, props.items) }</div>
        {/* Navigation */}
        <div className="table__nav__numbers">
          {/* Prev page arrow */}
          <div
            className={"table__nav__action prev" + (props.page === 0 ? ' disabled' : '')}
            onClick={() => props.page > 0 && props.onAction(-1)}>
            <NavArrowIcon className="table__nav__action-icon" />
          </div>
          {/* Numbers */}
          { 
            [...new Array(pages)].map((item, i) => {
              if(pages > 4) {
                if(props.page - i <= 1 && props.page - i >= -1)
                  return <div key={`table__nav:${i}`} className={"table__nav__number" + (i === props.page? ' active' : '')} onClick={() => props.jump(i)}>{ i + 1 }</div>
                else if(props.page - i === -2)
                  return <>
                    {pages > 5 && <div key={`table__nav-dots:${i}`} className="table__nav__number disabled">...</div>}
                    <div key={`table__nav:${i}`} className="table__nav__number" onClick={() => props.jump(pages - 1)}>{ pages }</div>
                  </>
                else if(props.page - i === 2)
                  return <>
                    <div key={`table__nav:${i}`} className="table__nav__number" onClick={() => props.jump(0)}>1</div>
                    {pages > 5 && <div key={`table__nav-dots:${i}`} className="table__nav__number disabled">...</div>}
                  </>
              } else {
                return <div key={`table__nav:${i}`} className={"table__nav__number" + (i === props.page? ' active' : '')} onClick={() => props.jump(i)}>{ i + 1 }</div>
              }
            })
          }
          {/* Next page arrow */}
          <div
            className={"table__nav__action next" + (props.page === (pages - 1) ? ' disabled' : '')}
            onClick={() => props.page < (pages - 1) && props.onAction(1)}>
            <NavArrowIcon className="table__nav__action-icon" />
          </div>
        </div>
      </div>
    </div>
  )
}

// helper function to display index and number of items showing on page
function getShowingInfo(page:number, perPage:number, items:number) {
  let from = page*perPage + 1;
  let to = items - from > 1 ? (items - from < perPage ? items : (page*perPage + perPage)) : from;
  return <>Showing <b>{from}-{to}</b> of <b>{items}</b> items</>
}