export interface TableHeadItemScheme {
  label: string,
  width?: string,
  type?: string,
  match?: string,
  edit?: string,
  remove?: string,
  objectMatch?: string,
  filter?: string
}

interface TableHeadScheme {
  items: TableHeadItemScheme[],
  layout: string
}

export default function TableHead(props: TableHeadScheme) {
  const { layout, items } = props;

  return (
    <div className="table__head" style={{gridTemplateColumns: layout}}>
      {
        items.map(({label}, i) => <div key={`th:${i}`} className="table__head-item">{label}</div>)
      }
    </div>
  )
}