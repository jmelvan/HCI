import { TableScheme } from ".";
import { getParams, _format } from "../../helpers";

// helper function to get table configuration
export function getTableConfiguration({ config, perPage, data }: TableScheme) {
  let configuration = {
    layout: '',
    params: {
      edit: [] as string[],
      remove: [] as string[]
    },
    isConfigLoading: false,
    perPage: perPage,
    data: data || [],
    show: data || [],
    isDataLoading: data === undefined
  }
  let filtersStructure = {} as Record<any, any>;
  // loop through table head elements and configure the table based on table setup
  config.map(({ width, type, edit, remove, match, filter, label, objectMatch }) => {
    // setup grid layout
    configuration.layout += width ? ` ${width}` : ' 1fr';
    // prepare filters scheme
    if(filter && match) {
      let complexMatch = {}
      if(objectMatch)
        complexMatch = { objectMatch }
      filtersStructure[match] = { label: label, match: match, type: filter, items: [], ...complexMatch };
    }
    // extract params (url placeholders) from defined actions
    if(type === 'actions'){
      // if edit url is defined
      edit && (configuration.params.edit = getParams(edit));
      // if remove url is defined
      remove && (configuration.params.remove = getParams(remove));
    }
  });
  // return table configuration and filters scheme
  return { filtersStructure, configuration };
}

// helper function to get filters data
export function getFiltersScheme(filtersStructure:Record<any, any>, data:Record<any, any>[]) {
  // loop through data, and scan possible values for specified filter
  data.map(item => {
    // loop through outside filters (probably 2 to 3, guess won't be more)
    for(let filter of Object.values(filtersStructure)){
      // item[match] can be array (e.g. [place 1, place 2]) so we have to cover that case also
      let toAdd;
      if(filter.objectMatch && item[filter.match].constructor === Object) {
        toAdd = [item[filter.match][filter.objectMatch]];
      } else if(Array.isArray(item[filter.match]) && filter.objectMatch) {
        let temp = _format(item[filter.match], filter.objectMatch);
        toAdd = Object.keys(temp);
      } else {
        toAdd = [item[filter.match]]
      }
      // loop throguh toAdd array and check if value exists in filters scheme items, add it if doesn't exist
      for(let addItem of toAdd)
        if(filtersStructure[filter.match].items.indexOf(addItem) === -1)
          filtersStructure[filter.match].items.push(addItem)
    }
  })
  // return filters with unique values
  return filtersStructure;
}

// helper function to filter given data based on given filters
export function filterData(filters:Record<any, any>, data:Record<any, any>[]) {
  // logic => item has to pass every filter to be shown
  return data.filter(item => {
    // create boolean array with number of elmenets as number of different filters, inicialize each child as false
    let shouldReturn = new Array(Object.keys(filters).length).fill(false);
    // loop through filters
    for(let [i, filter] of Object.values(filters).entries()) {
      // values can be string, object or array, so we have to transform everything to array to be consistent
      // let matchValues = Array.isArray(item[filter.match]) ? item[filter.match] : [item[filter.match]];
      let matchValues;
      if(filter.objectMatch && item[filter.match].constructor === Object) {
        matchValues = [item[filter.match][filter.objectMatch]];
      } else if(Array.isArray(item[filter.match])) {
        let temp = _format(item[filter.match], filter.objectMatch);
        matchValues = Object.keys(temp);
      } else {
        matchValues = [item[filter.match]]
      }
      // e.g. procut doesn't have to be assigned to any place
      if(matchValues.length === 0) shouldReturn[i] = true
      // loop through item values array made on the previous line, check if item passes filters
      for(let value of matchValues)
        if(filter.items.includes(value))
          shouldReturn[i] = true;
    }
    // check filtering logic (item has to pass every filter to be shown)
    if(shouldReturn.every(val => val === true))
      return item;
  })
}