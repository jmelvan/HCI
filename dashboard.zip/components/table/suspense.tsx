interface TableRowsSuspenseScheme {
  rows?: number,
  layout?: string,
  cols?: number
}

export default function TableRowsSuspense(props: TableRowsSuspenseScheme) {
  const { rows, layout, cols } = props;

  return <>
    {[...new Array(rows || 5)].map((r, i) =>
      <div key={`tr-suspense:${i}`} className="table__row" style={{gridTemplateColumns: layout}}>
        {[...new Array(cols || 5)].map((k, j) => <div key={`tr-suspense:${i}-${j}`} className="table__cell--preloader"></div>)}
      </div>
    )}
  </>
}