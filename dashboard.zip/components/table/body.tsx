import TableCell from "./cell";
import { TableHeadItemScheme } from "./head";
import TableRowsSuspense from "./suspense";

interface TableBodyScheme {
  items: Record<any, any>[],
  layout: string,
  isDataLoading: boolean,
  thead: TableHeadItemScheme[],
  params: Record<string, string[]>,
  perPage: number,
  onRemove?: (e: React.FormEvent<HTMLDivElement>, item: Record<any, any>) => void,
  onPublish?: (e: React.ChangeEvent<HTMLInputElement>, item: Record<any, any>) => void
}

export default function TableBody(props: TableBodyScheme) {
  const { items, isDataLoading, layout, thead, params, perPage } = props;

  if(isDataLoading)
    return <div className="table__body"><TableRowsSuspense rows={perPage} layout={layout} cols={thead.length} /></div>

  return (
    <div className="table__body">
      {
        // loop throught items (rows)
        items.map((item, i) =>
          <div key={`table__row:${i}`} className="table__row" style={{gridTemplateColumns: layout}}>
            { 
              // loop through signle item data values (table cells)
              thead.map((column, j) => 
                <TableCell key={`table__cell:${i}-${j}`} column={column} item={item} params={params} onRemove={e => props.onRemove && props.onRemove(e, item)} onPublish={e => props.onPublish && props.onPublish(e, item)} />
              )
            }
          </div>
        )
      }
    </div>
  )
}