import Link from "next/link";
import { replaceParams, _format } from "../../helpers";
import { DeleteIcon, EditIcon } from "../icons";
import { Image } from "../image";
import { TableHeadItemScheme } from "./head";

interface TableCellScheme {
  column: TableHeadItemScheme,
  item: Record<any, any>,
  params: Record<string, string[]>,
  onRemove?: (e: React.FormEvent<HTMLDivElement>) => void,
  onPublish?: (e: React.ChangeEvent<HTMLInputElement>) => void
}

export default function TableCell(props: TableCellScheme) {
  const { item, column: { match, type, objectMatch, ...rest }, params } = props;

  return (
    <div className="table__cell">
      {
        type !== 'actions' ?
          TableDataCell(item[match || 0], type, objectMatch, props.onPublish)
        :
          TableActionCell(rest, item, params, props.onRemove)
      }
    </div>
  )
}

// function that returns table cell value based on column data type
const TableDataCell = (value:any, type?:string, objectMatch?:string, onPublish?: (e: React.ChangeEvent<HTMLInputElement>) => void) => {
  if(type === 'img')
    return <Image src={value} fadeIn className="table-contain" />
  else if(type === 'boolean')
    return <input className="apple-switch" type="checkbox" onChange={onPublish} defaultChecked={value == true} />
  else if(type === 'list' && value.constructor === Array) {
    let temp = objectMatch && value.length > 0 ? Object.keys(_format(value, objectMatch)) : []
    return temp.join(", ")
  } else if(type === 'object')
    return objectMatch ? value[objectMatch] : ""

  return value;
}

// function that renders action cell and builds custom action URL-s for each item
const TableActionCell = (config:TableHeadItemScheme, item:Record<any, any>, params:Record<string, string[]>, onRemove?: (e: React.FormEvent<HTMLDivElement>) => void) => {
  // build remove URL - replace placeholders from provided action links
  let removeURL = replaceParams(config.remove || '', params.remove, item);
  // return actions table cell
  return <>
    {
      config.edit && <div className="action__icon">
        <Link href={replaceParams(config.edit, params.edit, item)}>
          <EditIcon />
        </Link>
      </div>
    }
    {
      config.remove && <div className="action__icon" data-remove={removeURL} onClick={onRemove}><DeleteIcon /></div>
    }
  </>
}