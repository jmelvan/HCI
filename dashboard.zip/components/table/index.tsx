'use client';

import { useEffect, useState } from "react"
import TableHead, { TableHeadItemScheme } from "./head";
import TableBody from "./body";
import TableNav from "./nav";
import { filterData, getFiltersScheme, getTableConfiguration } from "./helpers";
import API from '../../helpers/api'

export interface TableScheme {
  config: TableHeadItemScheme[],
  data?: Record<any, any>[],
  dataURL?: string,
  perPage?: number,
  search?: string,
  searchMatch?: string,
  filters?: Record<any, any>,
  model?: string,
  getFilters?: (filters:Record<any, any>) => void
}

export default function Table(props: TableScheme) {
  const [state, setState] = useState({
    layout: '', // table layout (css grid-template-columns value)
    params: {} as Record<string, string[]>, // action links url placeholders (params)
    isConfigLoading: true, // is table still loading configuration
    isDataLoading: true, // is data loading boolean
    data: [] as Record<any, any>[], // all data
    show: [] as Record<any, any>[], // data to show in table (differs from all data when searching)
    currentPageItems: [] as Record<any, any>[], // items on the current active page
    search: '', // search input value
    page: 0, // current active page
    perPage: 6, // items per page
  })
  // filters structure is the same as filters scheme but without any possible values for each filter
  const [filtersStructure, setfiltersStructure] = useState<Record<any, any>>({});
  // filters scheme expands filters structure and contains unique possible values for each filter
  const [filtersScheme, setFiltersScheme] = useState<Record<any, any>>({});

  // function to update wanted states
  const updateState = (states:Record<any, any>) => setState((prev) => ({...prev, ...states}));
  // function that returns paginated items, if page argument is provided, it overwrites current page value from the component state
  const paginate = (data:Record<any, any>[], page?:number) => data.slice(page || state.page * state.perPage, (page || state.page + 1) * state.perPage);
  // function that filters all items by search value from props, if search value is empty it returns all items
  const search = () => props.search !== '' ? state.data.filter(item => item[props.searchMatch || 0].toUpperCase().includes(props.search?.toUpperCase())) : filter();
  // function to filter items based on filters from props
  const filter = (data?:any) => props.filters ? filterData(props.filters, (data || state.data)) : (data || state.data);
  // function that stores data to state (fetched from API or other source)
  const storeData = (data:any) => updateState({ data: data || [], show: data || [], isDataLoading: false });

  // called on load
  useEffect(() => {
    const { filtersStructure, configuration } = getTableConfiguration(props);
    // get and store configuration to state
    updateState(configuration);
    // store filters scheme to state
    setfiltersStructure(filtersStructure);
    // fetch data if needed
    if(props.dataURL)
      API.get(props.dataURL).then(res => res.data).then(storeData)
  }, [])

  // callback when search input value changes (user searches)
  useEffect(() => updateState({ page: 0, show: search() }), [props.search])
  // callback when data is fetched, when data is searched, and when page is changed (pagination)
  useEffect(() => updateState({ currentPageItems: paginate(state.show) }), [state.show, state.page])
  // if dataURL is provided, filter again after data is fetched
  useEffect(() => {!state.isDataLoading && setFiltersScheme(getFiltersScheme(filtersStructure, state.data))}, [state.isDataLoading])
  // filters callback when all filters are loaded
  useEffect(() => {Object.keys(filtersScheme).length > 0 && props.getFilters && props.getFilters(filtersScheme)}, [filtersScheme])
  // called when user filters items
  useEffect(() =>  updateState({ show: filter(), page: 0 }), [props.filters])

  const removeItem = async (e: React.FormEvent<HTMLDivElement>, item: Record<any, any>) => {
    try {
      let removeURL = e.currentTarget.dataset.remove;
      // protection
      if(!removeURL) return;
      // confirm deleting
      if(!confirm("Are you sure you want to delete this item?")) return;
      // make api call
      await API.delete(removeURL)
      // if request is successfull, remove item from data
      // firstly copy data array
      let data = state.data;
      // now remove item from array
      data.splice(data.indexOf(item), 1)
      //store new array to state
      setState(prev => ({ ...prev, data: [...data], show: filter([...data]) }))
    } catch(e) {
      alert("Something went wrong while deleting this item. Please try again later.")
    }
  }

  const onPublish = async (e: React.ChangeEvent<HTMLInputElement>, item: Record<any, any>) => {
    try {
      // make api call
      await API.post(`/${props.model}/changeStatus/${item.id}`, { is_published: !item.is_published })
      // if request is successfull, change state with new published state
      // firstly copy data array
      let data = state.data;
      // change published status
      data[data.indexOf(item)].is_published = !item.is_published;
      //store new array to state
      setState(prev => ({ ...prev, data: [...data], show: filter([...data]) }))
    } catch(e) {
      alert("Something went wrong while publishing this item. Please try again later.")
    }
  }

  if(state.isConfigLoading)
    return <>...</>

  return (
    <div className="table-wrapper">
      <div className="table">
        <TableHead
          items={props.config}
          layout={state.layout}
        />
        <TableBody
          items={state.currentPageItems}
          layout={state.layout}
          isDataLoading={state.isDataLoading}
          perPage={state.perPage}
          thead={props.config}
          params={state.params}
          onRemove={removeItem}
          onPublish={onPublish}
        />
        <TableNav
          items={state.show.length}
          perPage={state.perPage}
          page={state.page}
          isDataLoading={state.isDataLoading}
          onAction={(action) => setState((prev) => ({...prev, page: prev.page + action}))}
          jump={(page) => setState((prev) => ({...prev, page: page}))}
        />
      </div>
    </div>
  )
}