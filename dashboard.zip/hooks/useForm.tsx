import React, { useEffect, useRef, useState } from "react";
import config, { ATTRIBUTE_TYPE_REPEATER } from "../config";
import { createFormData, _delete, _format, _update } from "../helpers";
import API from "../helpers/api"

function useForm<S>(initialState: S | (() => S), staticFields?: string[]) {
  const initialAttributes = (typeof initialState === 'object' && initialState !== null && 'attributes' in initialState && Array.isArray(initialState.attributes)) ? initialState.attributes : []
  const initialPrices = (typeof initialState === 'object' && initialState !== null && 'prices' in initialState && Array.isArray(initialState.prices)) ? initialState.prices : []
  // scheme is used to send request it contains translation objects
  const [scheme, updateScheme] = useState<Record<any, any>>(initialState || {});
  // formData is used to display values inside inputs
  const [formData, updateFormData] = useState<S>(initialState);
  // attributes are used on categories and products
  const [attributes, updateAttributes] = useState<any[]>(initialAttributes);
  // prices are used only on products
  const [prices, updatePrices] = useState<any[]>(initialPrices);
  // language defines current editing language
  const [language, updateLanguage] = useState<string>(config.fallbackLanguage);
  // errors
  const [error, setError] = useState(undefined);
  const [errors, setErrors] = useState<Record<string, any> | undefined>(undefined);
  // success
  const [success, setSuccess] = useState<any>(undefined);
  // has data been changed
  const [isDataChanged, setDataChanged] = useState(false);
  // boolean has use form passed first render
  const notInitialRender = useRef(false)

  useEffect(() => {
    // bypass first load
    if(!notInitialRender.current) {
      notInitialRender.current = true;
    } else {
      // data has been changed
      !isDataChanged && setDataChanged(true)
    }
  }, [scheme])

  // --------------------------------------
  // Global actions
  // --------------------------------------

  // function to change state on user input
  const handleInput = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    // update form data for live change
    updateFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
    // update scheme that would be sent to API -> onSave
    if(language === 'en' || staticFields?.includes(e.target.name))
      updateScheme((prev) => ({ ...prev, [e.target.name]: e.target.value }))
    else {
      // if creating new record and field is not specified for fallback language -> initialize field for fallback language
      let forFallbackLanguage = scheme[e.target.name] ? {} : { [e.target.name]: "" }
      // update scheme
      updateScheme((prev) => ({ ...prev, ...forFallbackLanguage, translations: {...(prev.translations || {}), [language]: {...(prev.translations && prev.translations[language] || { language: language }), [e.target.name]: e.target.value } } }))
    }
    // remove error when started typing
    if(errors && errors[e.target.name]) {
      // copy errors state
      let temp = errors;
      // delete wanted object
      delete temp[e.target.name];
      // update errors state
      setErrors({...temp});
    }
  }

  // function called when file is uploaded
  const handleFileUpload = (file: File, name: string) => {
    // update form data for live change
    updateFormData((prev) => ({ ...prev, [name]: file }))
    // images don't have translations, so it's in the top level of scheme
    updateScheme((prev) => ({ ...prev, [name]: file }))
  };

  // function to add or remove place from array
  const onPlaceAction = (e: React.FormEvent<HTMLDivElement>) => {
    // do the action
    let newArray = toggleFromArray((formData as any).places, parseInt(e.currentTarget.dataset.id || "0"))
    // update form data for live change
    updateFormData((prev) => ({ ...prev, places: [...newArray] }))
    // update scheme for request
    updateScheme((prev) => ({ ...prev, places: [...newArray] }))
  }
  
  // function to add or remove tag from array
  const onTagAction = (e: React.FormEvent<HTMLDivElement>) => {
    // do the action
    let newArray = toggleFromArray((formData as any).tags, parseInt(e.currentTarget.dataset.id || "0"))
    // update form data for live change
    updateFormData((prev) => ({ ...prev, tags: [...newArray] }))
    // update scheme for request
    updateScheme((prev) => ({ ...prev, tags: [...newArray] }))
  }

  // --------------------------------------
  // Attributes actions
  // --------------------------------------

  // function to change attributes state on user action with attributes
  const handleAttributeInput = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    // attributes have complex indexing (we're indexing nested arrays of objects)
    // e.g. 0/value/1/key => indexes value field of attribute with index 0, and that value filed is another nested array. 
    // We also index key field of element with index 1 from that nested array
    let path = e.target.name.split("/");
    // copy attributes so we can work on temp variable
    let temp:any = attributes;
    // different actions on fallback and other languages
    if(language === config.fallbackLanguage || path[1] === 'type') {
      // update given path with recursion
      _update(temp, path, e.target.value)
    } else {
      // extract attribute index
      let index = path.shift()!;
      // check if translation for selected language exists. If not, create empty object
      if(!temp[index].translations[language])
        temp[index].translations[language] = { language: language }
      // update given path with recursion
      _update(temp[index].translations[language], path, e.target.value)
    }
    // change data change so button user can save input
     !isDataChanged && setDataChanged(true)
     // update state
    updateAttributes([...temp])
  }

  // function to mark attribute for deleting
  const deleteAttribute = (e: React.FormEvent<HTMLDivElement>) => { 
    // change data change so button user can save input
    !isDataChanged && setDataChanged(true)
    // update state
    updateAttributes([..._delete(attributes, e.currentTarget.dataset.index || "")]) 
  }
  // function to create new attribute
  const addAttribute = (simple?: boolean) => {
    // if is simple attribute it's just string, if it's complex it's object with value that is array of objects
    let initValue = simple === true ? "" : { value: [{}]};
    // update attributes state
    updateAttributes((prev) => ([...prev, { value: initValue, type: "1", category_id: scheme.type_id, translations: {} }]))
  }
  // function to change order of the attributes
  const moveAttribute = (e: React.FormEvent<HTMLDivElement>) => {
    let index = e.currentTarget.dataset.attribute || "0";
    let direction = e.currentTarget.dataset.direction;
    let swapIndex = parseInt(index) + (direction === "up" ? -1 : 1)
    // clone attributes array
    let temp:any = attributes;
    // swap positions
    [temp[index], temp[swapIndex]] = [temp[swapIndex], temp[index]]
    updateAttributes([...temp]);
  }

  // function to delete single repeater key value pair
  const deleteRepeaterPair = (e: React.FormEvent<HTMLDivElement>) => updateAttributes([...repeaterPairAction(attributes, "delete", e.currentTarget.dataset.attribute, e.currentTarget.dataset.pair)])
  // function to add new repeater pair (repeater is type of single attribute)
  const addNewRepeaterPair = (attribute_index: number) => updateAttributes([...repeaterPairAction(attributes, "add", attribute_index)])


  // --------------------------------------
  // Prices actions
  // --------------------------------------

  // function to change prices state on user action with prices
  const handlePriceInput = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    let path = e.target.name.split("/");
    // copy prices so we can work on temp variable
    let temp:any = prices;
    temp[path[0]][path[1]] = e.target.value;
    // data has been changed
    !isDataChanged && setDataChanged(true)
    // update prices state
    updatePrices([...temp]);
  }

  // function to mark price for deleting
  const deletePrice = (e: React.FormEvent<HTMLDivElement>) => {
    // data has been changed
    !isDataChanged && setDataChanged(true)
    // update prices state
     updatePrices([..._delete(prices, e.currentTarget.dataset.index || "")])
  }
  // function to create new price
  const addPrice = () => { 
    // data has been changed
    !isDataChanged && setDataChanged(true) 
    // update prices state
    updatePrices((prev) => ([...prev, { }])); 
  }


  // --------------------------------------
  // Language actions
  // --------------------------------------

  // function called on language change
  const changeLanguage = (language: string) => {
    // protection (check if app supports given language)
    if(!config.languages.includes(language)) return;
    // change language logic below
    const { translations, attributes, ...fields } = scheme;
    // store language to state
    updateLanguage(language);
    // logic to translate fields or add translation for newly created ones
    let translateFields:any = {}
    if(language === config.fallbackLanguage)
      translateFields = fields;
    else
      Object.keys(fields).map(field => {
        // we only want to change translatable fields
        if(staticFields?.includes(field)) return;
        // translate if possible, if not - init empty string
        translateFields[field] = (translations && translations[language] && translations[language][field]) || ""
      })
    // update form data
    updateFormData((prev) => ({ ...prev, ...(translateFields) }))
  }


  // --------------------------------------
  // Submit
  // --------------------------------------

  // function on submit
  const submit = async (action: string) => {
    try {
      let attributesObj = {}, pricesObj = {};
      // if attributes are used loop through each, transform their translation object -> array and add them order index
      if(attributes.length) {
        attributes.map((item, i) => {
          item.order = i;
          item.translations = Object.values(item.translations);
        })
        attributesObj = { attributes: attributes }
      }
      // check if prices are defined
      if(prices.length)
        pricesObj = { prices: prices }
      // translations object -> array
      let translations = scheme.translations ? Object.values(scheme.translations) : []
      // extract data for request
      let data = { ...scheme, translations: translations, ...attributesObj, ...pricesObj };
      // send request to api
      let res = await API.post(action, createFormData(data));
      // on success, set success status
      setSuccess(res.data)
      // return changed flag to false
      setDataChanged(false)
      // set errors to undefined if success
      setErrors(undefined);
      // set error to undefined
      setError(undefined);

    } catch(e: any) {
      // if api return errors, store them to errors state
      e.response.data.errors && setErrors(_format(e.response.data.errors, 'field'));
      e.response.data.error && setError(e.response.data.error);
    }
  }

  return { 
    formData,
    language,
    attributes,
    prices,
    error,
    errors,
    success,
    isDataChanged,
    handleInput,
    handleFileUpload,
    handlePriceInput,
    changeLanguage,
    submit,
    handleAttributeInput,
    deleteAttribute,
    addAttribute,
    moveAttribute,
    addNewRepeaterPair,
    deleteRepeaterPair,
    addPrice,
    deletePrice,
    onPlaceAction,
    onTagAction
  };
}

export default useForm;

// function to add or remove repeater pair
function repeaterPairAction(arr:any[], action:string, attribute?:string | number, pair?:string | number) {
  // clone attributes array
  let temp:any = arr;
  // check if attribute value is array (not simple attribute), and attribute type is repeater
  if(attribute === undefined || !Array.isArray(temp[attribute].value.value) || temp[attribute].type != ATTRIBUTE_TYPE_REPEATER) return arr;
  // do action
  if(action === "add")
    temp[attribute].value.value.push({});
  else
    temp[attribute].value.value.splice(pair, 1);
  // return temp array
  return temp
}

// function to toggle item from array
function toggleFromArray(arr:any[], item:number) {
  // copy places so we can work on temporary variable
  let temp:any = arr || [];
  // if place is included - remove it, else if not - add it (toggle logic)
  if(temp.includes(item))
    temp.splice(temp.indexOf(item), 1)
  else
    temp.push(item)
  // return new array
  return temp;
}