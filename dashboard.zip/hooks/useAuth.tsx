'use client';

import { useEffect, useState } from 'react';
import { safeLocalStorage } from '../helpers';

const useAuth = () => {
  const [token, setToken] = useState<string | null | undefined>(undefined);
  const [tokenLoaded, setTokenLoaded] = useState(false);

  useEffect(() => {
    // get token from local storage
    let storageToken = safeLocalStorage.getItem('token');
    // if token exists, store it to state
    storageToken && setToken(storageToken);
    // token is loaded
    setTokenLoaded(true)
  }, []);

  const setAuth = (token: string) => {
    safeLocalStorage.setItem('token', token);
    setToken(token);
  };

  const removeAuth = () => {
    safeLocalStorage.removeItem('token');
    setToken(null);
  };

  return { token, tokenLoaded, setAuth, removeAuth };
};

export default useAuth;