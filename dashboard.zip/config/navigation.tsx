import { CategoriesIcon, PlacesIcon, ProductsIcon, SettingsIcon } from "../components/icons";

export const navigation = [
  {
    label: 'Products',
    items: [
      {
        label: 'Categories',
        icon: <CategoriesIcon className="sidebar__nav-item__icon" />,
        slug: 'categories',
        children: [
          {
            label: 'New Category',
            slug: 'new'
          },
          {
            label: 'Edit Category',
            slug: 'edit'
          },
        ]
      },
      {
        label: 'Products',
        icon: <ProductsIcon className="sidebar__nav-item__icon" />,
        slug: 'products',
        children: [
          {
            label: 'New Product',
            slug: 'new'
          },
          {
            label: 'Edit Product',
            slug: 'edit'
          },
        ]
      }
    ],
  },
  {
    label: 'General',
    items: [
      {
        label: 'Places',
        icon: <PlacesIcon className="sidebar__nav-item__icon" />,
        slug: 'places',
        children: [
          {
            label: 'New Place',
            slug: 'new'
          },
          {
            label: 'Edit Place',
            slug: 'edit'
          },
        ]
      },
      {
        label: 'Settings',
        icon: <SettingsIcon className="sidebar__nav-item__icon" />,
        slug: 'settings'
      }
    ],
  }
]