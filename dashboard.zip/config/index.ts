const config = {
  // api: "http://localhost:3333",
  //api: "http://167.71.54.162:3333",
  //assets: "http://167.71.54.162:8080",
  api: "http://167.71.54.162:8081",
  assets: "http://167.71.54.162:8082",
  languages: ['en', 'hr'],
  languagesFlags: {
    'en': "🇬🇧",
    'hr': "🇭🇷"
  },
  fallbackLanguage: 'en'
}

export const attribute_types = [
  {
    id: "1",
    label: "Text"
  },
  {
    id: "2",
    label: "Long text"
  },
  {
    id: "3",
    label: "Repeater"
  },
]
export const ATTRIBUTE_TYPE_TEXT = '1';
export const ATTRIBUTE_TYPE_LONG_TEXT = '2';
export const ATTRIBUTE_TYPE_REPEATER = '3';

export default config;