interface AttributeFields {
  id?: number,
  value?: string,
  category_id?: number
}

interface AttributesScheme extends AttributeFields {
  translations?: Record<string, AttributeFields>[]
}

interface CategoryFields {
  id?: number,
  name?: string,
  name_plural?: string,
  image?: File | string,
  type_id?: number,
}

export interface CategoryScheme extends CategoryFields {
  translations?: Record<string, CategoryFields>[],
  attributes?: AttributesScheme[]
}