interface AttributeValues {
  key: string,
  value: Record<string, string>[]
}

interface ProductAttributeFields {
  id: number,
  value: AttributeValues,
  category_id: number,
  type: string,
  delete?: boolean
}

export interface ProductAttributesScheme extends ProductAttributeFields {
  translations?: Record<string, ProductAttributeFields>
}

export interface ProductPricesScheme {
  id?: number,
  icon_id?: number,
  size?: string,
  price?: string,
  place_id?: number,
  delete?: boolean
}

interface ProductFields {
  id?: number,
  name?: string,
  name_plural?: string,
  image?: File | string,
  category_id?: number,
  places?: number[],
  tags?: number[],
  prices?: ProductPricesScheme[]
}

export interface ProductScheme extends ProductFields {
  translations?: Record<string, ProductFields>[],
  attributes?: ProductAttributesScheme[]
}