export interface TypeScheme {
  id: number,
  name: string,
  name_plural: string,
  collection_name: string
}