export interface PlaceSingleScheme{
  id: number,
  image: string,
  slug: string,
  name: string
}