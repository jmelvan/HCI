import Route from '@ioc:Adonis/Core/Route'

// user routes
Route.group(() => {
  Route.post('/create', 'CategoriesController.create').middleware(['auth', 'ObjectParser'])
  Route.post('/update/:category', 'CategoriesController.update').middleware(['auth', 'ObjectParser'])
  Route.post('/changeStatus/:category', 'CategoriesController.changeStatus').middleware(['auth'])
  Route.delete('/delete/:category', 'CategoriesController.delete').middleware(['auth'])
  Route.get('/admin', 'CategoriesController.getAll').middleware(['auth'])
  Route.get('/admin/:category', 'CategoriesController.get').middleware(['auth'])
}).prefix('/category')