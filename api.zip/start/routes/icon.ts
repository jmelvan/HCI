import Route from '@ioc:Adonis/Core/Route'

// user routes
Route.group(() => {
  Route.get('/', 'IconsController.index').middleware(['auth'])
}).prefix('/icon')