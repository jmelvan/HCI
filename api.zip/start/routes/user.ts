import Route from '@ioc:Adonis/Core/Route'

// user routes
Route.group(() => {
  // update user data ( only password )
  Route.post('/update', 'UsersController.update').middleware(['auth'])
  // route for login
  Route.post('/login', 'UsersController.login')
  // route for getting user data
  Route.get('/', 'UsersController.index').middleware(['auth'])
}).prefix('/user')