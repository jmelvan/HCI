import Route from '@ioc:Adonis/Core/Route'

// user routes
Route.group(() => {
  Route.post('/create', 'TypesController.create').middleware(['auth'])
  Route.post('/update/:type', 'TypesController.update').middleware(['auth'])
  Route.get('/', 'TypesController.index')
  Route.delete('/delete/:type', 'TypesController.delete').middleware(['auth'])
}).prefix('/type')