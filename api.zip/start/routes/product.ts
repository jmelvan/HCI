import Route from '@ioc:Adonis/Core/Route'

// user routes
Route.group(() => {
  Route.post('/create', 'ProductsController.create').middleware(['auth', 'ObjectParser'])
  Route.post('/update/:product', 'ProductsController.update').middleware(['auth', 'ObjectParser'])
  Route.post('/changeStatus/:product', 'ProductsController.changeStatus').middleware(['auth'])
  Route.delete('/delete/:product', 'ProductsController.delete').middleware(['auth'])
  Route.get('/admin', 'ProductsController.getAll').middleware(['auth'])
  Route.get('/admin/:product', 'ProductsController.get').middleware(['auth'])
  Route.get('/:product', 'ProductsController.index')
}).prefix('/product')