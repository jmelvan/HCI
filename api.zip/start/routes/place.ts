import Route from '@ioc:Adonis/Core/Route'

// user routes
Route.group(() => {
  Route.post('/create', 'PlacesController.create').middleware(['auth'])
  Route.post('/update/:place', 'PlacesController.update').middleware(['auth'])
  Route.delete('/delete/:place', 'PlacesController.delete').middleware(['auth'])
  Route.get('/admin', 'PlacesController.getAll').middleware(['auth'])
  Route.get('/:place', 'PlacesController.get')/*.middleware(['auth'])*/
  Route.get('/:place/categories', 'PlacesController.getCategories')
  Route.get('/:place/:category/products', 'PlacesController.getProducts')
}).prefix('/place')