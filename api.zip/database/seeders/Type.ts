import BaseSeeder from '@ioc:Adonis/Lucid/Seeder'
import { AllowedLanguagesType } from 'App/Enums/TranslationEnums';
import Type from 'App/Models/Type'


const new_types = [
  {
    name: "Drink",
    name_plural: "Drinks",
    collection_name: "Drinks selection"
  },
  {
    name: "Food",
    name_plural: "Foods",
    collection_name: "Foods selection"
  },
]

const types_translation = [
  {
    name: "Piće",
    name_plural: "Pića",
    collection_name: "Selekcija pića",
    language: "hr" as AllowedLanguagesType
  },
  {
    name: "Hrana",
    name_plural: "Hrana",
    collection_name: "Selekcija hrane",
    language: "hr" as AllowedLanguagesType
  }
]

export default class extends BaseSeeder {
  public async run () {
    // Write your database queries inside the run method
    for(let [key, type] of new_types.entries()) {
      let new_type = await Type.create(type);
      await new_type.related("translations").create(types_translation[key])
    }
  }
}
