import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class extends BaseSchema {
  protected tableName = 'categories'
  protected translationTableName = 'category_translations'

  public async up () {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').primary();

      table.string('name', 128).notNullable()
      table.string('name_plural', 128).notNullable()
      table.integer("type_id").references("types.id").onDelete('CASCADE');
      table.boolean("is_published").defaultTo(true).notNullable()
      table.string('image', 512)

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })
    })

    // create translation table
    this.schema.createTable(this.translationTableName, (table) => {
      table.increments('id').primary();

      table.string('name', 128).notNullable()
      table.string('name_plural', 128).notNullable()
      // assign language and references id
      table.string('language', 32).notNullable()
      table.integer('category_id').references('categories.id').notNullable().onDelete('CASCADE');
      table.unique(['category_id', 'language']);
    })
  }

  public async down () {
    this.schema.dropTable(this.translationTableName)
    this.schema.dropTable(this.tableName)
  }
}
