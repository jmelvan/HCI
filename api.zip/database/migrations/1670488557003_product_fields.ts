import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class extends BaseSchema {
  protected tableName = 'product_fields'
  protected translation_tableName = 'product_field_translations'
  public async up () {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      table.integer('product_id').notNullable().references("products.id").onDelete("CASCADE")
      table.integer('type').notNullable()
      table.integer('order')
      table.jsonb('value')

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })
    })
    this.schema.createTable(this.translation_tableName, (table) => {
      table.increments('id')
      table.integer('product_field_id').notNullable().references("product_fields.id").onDelete("CASCADE")
      table.jsonb('value')
      table.string('language', 32)
    })
  }

  public async down () {
    this.schema.dropTable(this.translation_tableName);
    this.schema.dropTable(this.tableName)
  }
}
