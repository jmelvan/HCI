import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class extends BaseSchema {
  protected tableName = 'product_tags'

  public async up () {
    this.schema.createTable(this.tableName, (table) => {
      table.integer("product_id").unsigned().references("products.id").onDelete("CASCADE").notNullable()
      table.integer("attribute_id").unsigned().references("category_attributes.id").onDelete("CASCADE").notNullable()
      table.primary(['product_id', 'attribute_id'])
    })
  }

  public async down () {
    this.schema.dropTable(this.tableName)
  }
}
