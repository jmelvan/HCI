import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class extends BaseSchema {
  protected tableName = 'category_attributes'
  protected translationTableName = 'category_attribute_translations'

  public async up () {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      // value
      table.string('value', 512).notNullable()
      // fk
      table.integer('category_id').references('categories.id').onDelete('CASCADE');
      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })
    })
    // translations table
    this.schema.createTable(this.translationTableName, (table) => {
      table.increments('id')
      // value
      table.string('value', 512).notNullable()
      // assign language and references id
      table.string('language', 32).notNullable()
      table.integer('category_attribute_id').notNullable().references('category_attributes.id').onDelete('CASCADE');
      table.unique(['category_attribute_id', 'language']);
    })
  }

  public async down () {
    this.schema.dropTable(this.translationTableName)
    this.schema.dropTable(this.tableName)
  }
}
