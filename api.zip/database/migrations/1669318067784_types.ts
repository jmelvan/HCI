import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class extends BaseSchema {
  protected tableName = 'types'
  protected translationTableName = 'type_translations'

  public async up () {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').primary();

      table.string('name', 128).notNullable()
      table.string('name_plural', 128).notNullable()
      table.string('collection_name', 128).notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })
    })

    // create translation table
    this.schema.createTable(this.translationTableName, (table) => {
      table.increments('id').primary();

      table.string('name', 128).notNullable()
      table.string('name_plural', 128).notNullable()
      table.string('collection_name', 128).notNullable()
      // assign language and references id
      table.string('language', 32).notNullable()
      table.integer('type_id').references('types.id').notNullable().onDelete('CASCADE');
      table.unique(['type_id', 'language']);
    })
  }

  public async down () {
    this.schema.dropTable(this.translationTableName)
    this.schema.dropTable(this.tableName)
  }
}
