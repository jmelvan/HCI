import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { AllowedLanguages } from 'App/Enums/TranslationEnums'

export default class CategoryValidator {
  constructor(protected ctx: HttpContextContract) {
  }

  public schema = schema.create({
    name: schema.string(),
    name_plural: schema.string(),
    is_published: schema.boolean.optional(),
    type_id: schema.number([
      rules.exists({table: 'types', column: 'id'})
    ]),
    image: schema.file.optional({
      size: '3mb',
      extnames: ['jpg', 'gif', 'png', 'webp', 'JPG', 'GIF', 'PNG', 'WEBP'],
    }),
    // translations
    translations: schema.array.optional().members(
      schema.object().members({
        name: schema.string(),
        name_plural: schema.string(),
        language: schema.enum(Object.values(AllowedLanguages))
      })
    ),
    attributes: schema.array.optional().members(
      schema.object().members({
        id: schema.number.optional([
          rules.exists({table: 'category_attributes', column: 'id'})
        ]),
        value: schema.string(),
        delete: schema.boolean.optional(),
        translations: schema.array.optional().members(
          schema.object().members({
            value: schema.string(),
            language: schema.enum(Object.values(AllowedLanguages))
          })
        )
      })
    )
  })

  // cache scheme
  public cacheKey = this.ctx.routeKey;

  public messages: CustomMessages = {
    '*': (field, rule) => {
      return `${rule} validation error on ${field}`
    },
    'required': 'This field is required.'
  }
}
