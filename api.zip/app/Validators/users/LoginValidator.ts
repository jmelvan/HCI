import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class LoginValidator {
  constructor(protected ctx: HttpContextContract) {}

  public schema = schema.create({
    email: schema.string([rules.email()]),
    password: schema.string([
      rules.minLength(8)
    ])
  })

  public messages: CustomMessages = {
    '*': (field, rule) => {
      return `${rule} validation error on ${field}`
    },
    'email.required': 'Email is required to login.',
    'password.required': 'Password is required to login.',
    'password.minLength': 'Password minimum lenght is 8.',
    'email.email': 'Please input email in right format.'
  }
}
