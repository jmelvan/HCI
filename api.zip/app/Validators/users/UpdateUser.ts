import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class UpdateUserValidator {
  constructor(protected ctx: HttpContextContract) {}
  public schema = schema.create({
    password: schema.string({}, [
      // need to send password_confirmation
      rules.confirmed('passwordConfirm'),
      // min 8 lenght
      rules.minLength(8)
    ]),
    oldPassword: schema.string({}, [
      rules.minLength(8)
    ])
  })

  public messages: CustomMessages = {
    '*': (field, rule) => {
      return `${rule} validation error on ${field}`
    },
    'required': 'This field is required to change data.',
    // password validation messages
    'password.confirm': 'Passwords are not same.',
    'password.minLenght': 'Minimal lenght of password is 8 characters.'
  }
}
