import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { ProductAttributeTypes } from 'App/Enums/ProductFieldEnum'
import { AllowedLanguages } from 'App/Enums/TranslationEnums'


export default class ProductValidator {
  constructor(protected ctx: HttpContextContract) {}


  public schema = schema.create({
    // name
    name: schema.string(),
    // uploaded image
    image: schema.file.optional({
      size: '3mb',
      extnames: ['jpg', 'gif', 'png', 'webp', 'JPG', 'GIF', 'PNG', 'WEBP'],
    }),
    is_published: schema.boolean.optional(),
    // product category
    category_id: schema.number([
      rules.exists({table: 'categories', column: 'id'})
    ]),
    prices: schema.array.optional().members(schema.object().members({
      // id for updating/deleting existing price
      id: schema.number.optional([
        rules.exists({table: 'product_prices', column: 'id'})
      ]),
      delete: schema.boolean.optional(),
      size: schema.string(),
      price: schema.string(),
      icon_id: schema.number([rules.exists({table: 'icons', column: 'id'})]),
      place_id: schema.number([rules.exists({table: 'places', column: 'id'})])
    })),
    // assigned tags
    tags: schema.array.optional().members(schema.number([rules.exists({table: 'category_attributes', column: 'id'})])), 
    // assigned places
    places: schema.array.optional().members(schema.number([rules.exists({table: 'places', column: 'id'})])),
    // product attributes
    attributes: schema.array.optional().members(schema.object().members({
      // id for updating/deleting attribute
      id: schema.number.optional([
        rules.exists({table: 'product_fields', column: 'id'})
      ]),
      // order for display
      order: schema.number(),
      // delete indicator
      delete: schema.boolean.optional(),
      // attribute type for value object
      type: schema.enum(Object.values(ProductAttributeTypes)),
      // attribute value
      value: schema.object().members({
        // attribute key
        key: schema.string.optional(),
        // attribute value
        value: schema.array([rules.minLength(1)]).members(schema.object().members({
          // repeater schema
          key: schema.string.optional(),
          value: schema.string()
        }))
      }),
      // attribute translation
      translations: schema.array.optional().members(schema.object().members({
        value: schema.object().members({
          key: schema.string.optional(),
          value: schema.array([rules.minLength(1)]).members(schema.object().members({
            key: schema.string.optional(),
            value: schema.string()
          }))
        }),
        language: schema.enum(Object.values(AllowedLanguages))
      })),
    })),
    // product translation
    translations:  schema.array.optional().members(schema.object().members({
      name: schema.string(),
      language: schema.enum(Object.values(AllowedLanguages))
    }))
  })

  // cache scheme
  public cacheKey = this.ctx.routeKey;

  public messages: CustomMessages = {
    '*': (field, rule) => {
      return `${rule} validation error on ${field}`
    },
    'required': 'This field is required.'
  }
}
