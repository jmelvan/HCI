import { schema, CustomMessages } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { AllowedLanguages } from 'App/Enums/TranslationEnums'

export default class TypeValidator {
  constructor(protected ctx: HttpContextContract) {}

  public schema = schema.create({
    name: schema.string(),
    name_plural: schema.string(),
    collection_name: schema.string(),
    // translations
    translations: schema.array.optional().members(
      schema.object().members({
        name: schema.string(),
        name_plural: schema.string(),
        collection_name: schema.string(),
        language: schema.enum(Object.values(AllowedLanguages))
      })
    )
  })

  // cache scheme
  public cacheKey = this.ctx.routeKey;
  
  public messages: CustomMessages = {
    '*': (field, rule) => {
      return `${rule} validation error on ${field}`
    },
    'required': 'This field is required.'
  }
}
