import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class PlaceValidator {
  constructor(protected ctx: HttpContextContract) {}

  // refs
  public refs = schema.refs({
    current_place : (this.ctx.params["place"]) ?  this.ctx.params["place"] : ''
  })

  public schema = schema.create({
    name: schema.string(),
    image: schema.file.optional({
      size: '1mb',
      extnames: ['jpg', 'gif', 'png', 'webp', 'JPG', 'GIF', 'PNG', 'WEBP'],
    }),
    slug: schema.string({}, [
      rules.unique({
        table: 'places',
        column: 'slug',
        whereNot: {
          slug: this.refs.current_place
        }
      }),
      rules.alphaNum({allow: ['underscore', 'dash']})
    ])
  })

  public messages: CustomMessages = {
    '*': (field, rule) => {
      return `${rule} validation error on ${field}`
    },
    'required': 'This field is required.',
    'unique': 'This field needs to be unique, please provide another one.',
    'alphaNum': 'This field can only contain letters and numbers'
  }
}
