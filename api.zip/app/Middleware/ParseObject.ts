import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class ParseObject {
  public async handle({request}: HttpContextContract, next: () => Promise<void>) {
    // 
    let {translations, attributes, prices, tags, places, ...rest} = request.body()
    // data to parse
    if(translations)
      translations = JSON.parse(translations)
    if(attributes)
      attributes = JSON.parse(attributes)
    if(prices)
      prices = JSON.parse(prices)
    if(tags)
      tags = JSON.parse(tags)
    if(places) 
      places = JSON.parse(places)
    // parse all objects
    request.updateBody({translations, attributes, prices, tags, places, ...rest})
    await next()
  }
}
