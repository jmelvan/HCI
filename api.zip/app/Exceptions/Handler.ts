import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
/*
|--------------------------------------------------------------------------
| Http Exception Handler
|--------------------------------------------------------------------------
|
| AdonisJs will forward all exceptions occurred during an HTTP request to
| the following class. You can learn more about exception handling by
| reading docs.
|
| The exception handler extends a base `HttpExceptionHandler` which is not
| mandatory, however it can do lot of heavy lifting to handle the errors
| properly.
|
*/

import Logger from '@ioc:Adonis/Core/Logger'
import HttpExceptionHandler from '@ioc:Adonis/Core/HttpExceptionHandler'

export default class ExceptionHandler extends HttpExceptionHandler {
  constructor() {
    super(Logger)
  }
  public async handle(error: any, ctx: HttpContextContract) {
    // if validation error send messages
    if (error.code === 'E_VALIDATION_FAILURE')
      return ctx.response.status(422).send(error.messages)
    // if login auth failed send message
    else if(error.code === 'E_INVALID_AUTH_UID' || error.code === 'E_INVALID_AUTH_PASSWORD') 
      return ctx.response.status(422).send({error: 'Sorry, the email and password you entered do not match our records.'})
    // if unauthorized access send message
    else if(error.code === 'E_UNAUTHORIZED_ACCESS')
      return ctx.response.status(422).send({error: 'You are not authorized!'});
    // database row not found
    else if(error.code === 'E_ROW_NOT_FOUND')
      return ctx.response.status(404).send({error: 'Invalid data input!'})
    return super.handle(error, ctx)
  }
}
