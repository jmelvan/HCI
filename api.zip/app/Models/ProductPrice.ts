import { DateTime } from 'luxon'
import { BaseModel, BelongsTo, belongsTo, column } from '@ioc:Adonis/Lucid/Orm'
import Icon from './Icon'
import Place from './Place'
import Product from './Product'

export default class ProductPrice extends BaseModel {
  @column({ isPrimary: true })
  public id: number

  @column()
  public icon_id: number

  @column()
  public place_id: number

  @column()
  public product_id: number

  @column()
  public price: string

  @column()
  public size: string

  @belongsTo(() => Icon, {
    localKey: 'id',
    foreignKey: 'icon_id'
  })
  public icon: BelongsTo<typeof Icon>

  @belongsTo(() => Place, {
    localKey: 'id',
    foreignKey: 'place_id'
  })
  public place: BelongsTo<typeof Place>

  @belongsTo(() => Product, {
    localKey: 'id',
    foreignKey: 'product_id'
  })
  public product: BelongsTo<typeof Product>

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
