import { DateTime } from 'luxon'
import { BaseModel, column, ManyToMany, manyToMany } from '@ioc:Adonis/Lucid/Orm'
import Product from './Product'

export default class Place extends BaseModel {
  
  public static routeLookupKey = 'slug'
  
  @column({ isPrimary: true })
  public id: number

  @column()
  public name: string

  @column()
  public slug: string

  @column()
  public image: string

  @manyToMany(() => Product, {
    localKey: 'id',
    relatedKey: 'id',
    pivotRelatedForeignKey: 'product_id',
    pivotForeignKey: 'place_id',
    pivotTable: 'product_places'
  })
  public products: ManyToMany<typeof Product>

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
