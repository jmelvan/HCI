import { DateTime } from 'luxon'
import { compose } from '@ioc:Adonis/Core/Helpers'
import { BaseModel, BelongsTo, belongsTo, column } from '@ioc:Adonis/Lucid/Orm'
import { AllowedProductFieldAttributes, AllowedProductFieldTypes } from 'App/Enums/ProductFieldEnum'
import Translation from './Mixins/Translation'
import Product from './Product'

/* Model for Product Fields */
export default class ProductField extends compose(
  BaseModel, 
  Translation('product_field', ['value'])
) {
  @column({ isPrimary: true })
  public id: number

  @column({serializeAs: null})
  public product_id: number

  @belongsTo(() => Product, {
    foreignKey: 'product_id',
    localKey: 'id'
  })
  public product: BelongsTo<typeof Product>

  @column({
    consume: (value: AllowedProductFieldTypes) => value.toString()
  })
  public type: AllowedProductFieldTypes

  @column()
  public value: AllowedProductFieldAttributes 

  @column()
  public order: number

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
