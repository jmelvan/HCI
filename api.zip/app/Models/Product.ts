import { DateTime } from 'luxon'
import { BaseModel, BelongsTo, belongsTo, column, HasMany, hasMany, ManyToMany, manyToMany } from '@ioc:Adonis/Lucid/Orm'
import { compose } from '@ioc:Adonis/Core/Helpers'
import Category from './Category'
import ProductField from './ProductField'
import Translation from './Mixins/Translation'
import CategoryAttribute from './CategoryAttribute'
import Place from './Place'
import ProductPrice from './ProductPrice'

export default class Product extends compose(
  BaseModel, 
  Translation('Product', ['name'])
) {
  @column({ isPrimary: true })
  public id: number

  @column()
  public name: string

  @column()
  public image: string

  @column()
  public category_id: number

  @column()
  public is_published: boolean

  @belongsTo(() => Category, {
    foreignKey: 'category_id',
    localKey: 'id'
  })
  public category: BelongsTo<typeof Category>

  @hasMany(() => ProductField, {
    foreignKey: 'product_id',
    localKey: 'id'
  })
  public attributes: HasMany<typeof ProductField>

  @hasMany(() => ProductPrice, {
    localKey: 'id',
    foreignKey: 'product_id'
  })
  public prices: HasMany<typeof ProductPrice>
  
  @manyToMany(() => CategoryAttribute, {
    localKey: 'id',
    relatedKey: 'id',
    pivotForeignKey: 'product_id',
    pivotRelatedForeignKey: 'attribute_id',
    pivotTable: 'product_tags'
  })
  public tags: ManyToMany<typeof CategoryAttribute>

  @manyToMany(() => Place, {
    localKey: 'id',
    relatedKey: 'id',
    pivotForeignKey: 'product_id',
    pivotRelatedForeignKey: 'place_id',
    pivotTable: 'product_places'
  })
  public places: ManyToMany<typeof Place>

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
