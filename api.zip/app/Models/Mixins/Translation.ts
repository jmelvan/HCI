import { NormalizeConstructor } from '@ioc:Adonis/Core/Helpers'
import { BaseModel, column, HasMany, hasMany } from '@ioc:Adonis/Lucid/Orm'
import {  AllowedLanguagesType } from 'App/Enums/TranslationEnums'

/**
 * Generates the translation model used in the relation.
 */
function TranslationModelFactory (tableName: string, columnNames: string[], foreignKey: string) {
  class TranslationModel extends BaseModel {
    public static table = tableName

    @column({ isPrimary: true, serializeAs: null })
    public id: number

    @column()
    public language: AllowedLanguagesType

  }

  /**
   * Adds decorator "column" to the defined columns and foreign key.
   */
  for (const columnName of columnNames) {
    TranslationModel.prototype[columnName] = null
    if(columnName !== foreignKey)
      column()(TranslationModel.prototype, columnName)
    else 
    column({serializeAs: null})(TranslationModel.prototype, columnName)
  }

  

  return TranslationModel
}

export default function (modelName: string, columnNames: string[], options?: {
  tableName?: string,
  localKey?: string,
  foreignKey?: string,
}) {
  return function<T extends NormalizeConstructor<typeof BaseModel>> (Base: T) {
    const opts = {
      tableName: `${modelName.toLowerCase()}_translations`,
      localKey: 'id',
      foreignKey: `${modelName.toLocaleLowerCase()}_id`,
      ...options,
    }

    const TranslationModel = TranslationModelFactory(opts.tableName, [opts.foreignKey, ...columnNames], opts.foreignKey)

    /**
     * The actual "Trait".
     */
    class TranslationMixin extends Base {
      /**
       * Because the relationship requires it, we're duplicating the column declaration here.
       */
      @column({ isPrimary: true })
      public id: any

      @hasMany(() => TranslationModel, {
        localKey: opts.localKey,
        foreignKey: opts.foreignKey,
      })
      public translations: HasMany<typeof TranslationModel>

    }

    return TranslationMixin
  }
}