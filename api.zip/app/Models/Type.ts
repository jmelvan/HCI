import { DateTime } from 'luxon'
import { compose } from '@ioc:Adonis/Core/Helpers'
import { BaseModel, column, HasMany, hasMany } from '@ioc:Adonis/Lucid/Orm'
import Translation from './Mixins/Translation'
import Category from './Category'

export default class Type extends compose(
  BaseModel, 
  Translation('Type', ['name', 'name_plural', 'collection_name'])
) {
  @column({ isPrimary: true })
  public id: number

  @column()
  public name: string

  @column()
  public name_plural: string

  @column()
  public collection_name: string

  @hasMany(() => Category, {
    foreignKey: 'type_id',
    localKey: 'id'
  })
  public categories: HasMany<typeof Category> 

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
