import { DateTime } from 'luxon'
import { compose } from '@ioc:Adonis/Core/Helpers'
import { BaseModel, BelongsTo, belongsTo, column, HasMany, hasMany } from '@ioc:Adonis/Lucid/Orm'
import Translation from './Mixins/Translation'
import CategoryAttribute from './CategoryAttribute'
import Type from './Type'

export default class Category extends compose(
  BaseModel, 
  Translation('Category', ['name', 'name_plural'])
) {
  @column({ isPrimary: true })
  public id: number

  @column()
  public type_id: number

  @column()
  public name: string

  @column()
  public is_published: boolean

  @column()
  public name_plural: string

  @column()
  public image: string

  @hasMany(() => CategoryAttribute, {
    foreignKey: 'category_id',
    localKey: 'id'
  })
  public attributes: HasMany<typeof CategoryAttribute>

  @belongsTo(() => Type, {
    foreignKey: 'type_id',
    localKey: 'id'
  })
  public type: BelongsTo<typeof Type>

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
