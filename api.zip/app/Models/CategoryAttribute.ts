import { DateTime } from 'luxon'
import { compose } from '@ioc:Adonis/Core/Helpers'
import { BaseModel, BelongsTo, belongsTo, column } from '@ioc:Adonis/Lucid/Orm'
import Category from './Category'
import Translation from './Mixins/Translation'

export default class CategoryAttribute extends compose(
  BaseModel, 
  Translation('category_attribute', ['value'])
) {
  @column({ isPrimary: true })
  public id: number

  @column()
  public category_id: number

  @column()
  public value: string

  @belongsTo(() => Category, {
    foreignKey: 'category_id',
    localKey: 'id'
  })
  public category: BelongsTo<typeof Category>

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
