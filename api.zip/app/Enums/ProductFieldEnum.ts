/* 
  Product Fields ( Attributes )
*/

import { AllowedLanguagesType } from "./TranslationEnums"

/* Product*/
export enum ProductAttributeTypes {
  text = '1', 
  long_text = '2',
  repeater = '3'
}

export type ProductFieldObjectType = {
  [ProductAttributeTypes.text], [ProductAttributeTypes.long_text]: {
    key?: string,
    value: string
  }
  [ProductAttributeTypes.repeater]: {
    key?: string,
    value: {key: string, value: string}[]
  }
}

export type AllowedProductFieldAttributes = ProductFieldObjectType[ProductAttributeTypes.text] | ProductFieldObjectType[ProductAttributeTypes.long_text] | ProductFieldObjectType[ProductAttributeTypes.repeater];

export type AllowedProductFieldTypes =  
  1 | ProductAttributeTypes.text | 
  2 | ProductAttributeTypes.long_text |
  3 | ProductAttributeTypes.repeater;

/* REQUEST ENUMS */
export interface ProductFieldRequestData {
  id?: number,
  order: number,
  delete?: boolean,
  type: AllowedProductFieldTypes,
  value: {
    key?: string,
    value: {
      key?: string,
      value: string
    }[]
  },
  translations?: {
    value: {
      key?: string,
      value: {
        key?: string,
        value: string
      }[]
    },
    language: AllowedLanguagesType
  }[]
}