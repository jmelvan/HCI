
export enum AllowedLanguages {
  hr = 'hr'
}

export type AllowedLanguagesType = 
  | 'hr' | AllowedLanguages.hr;