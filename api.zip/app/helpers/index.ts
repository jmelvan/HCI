// function to format array to object with leading key
export function _format<T>(array:T[], lead:string) : Record<string, T> {
  // init object
  var formated = {};
  // loop through elements of array
  for (let item of array)
      formated[item[lead]] = item;
  // return formated object
  return formated;
}