// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

import { AllowedLanguagesType } from "App/Enums/TranslationEnums";
import { _format } from "App/helpers";
import Category from "App/Models/Category";
import CategoryAttribute from "App/Models/CategoryAttribute";

export default class CategoryAttributesController {

  // function for createing attributes
  public async createMany(attributes: Attribute[], category: Category) {
    //create many category attributes
    await
    (
      async () => {
        for await (const attribute of attributes)
        {
          // destruct elements
          let {value, translations} = attribute;
          // make new attribute
          let new_attribute = await CategoryAttribute.create({value});
          // if translations assigned create translation for attribute
          if(translations)
            await new_attribute.related('translations').updateOrCreateMany(translations, ['language']);
          // assign attribute to cattegory
          await new_attribute.related('category').associate(category);
        }
      }
    )();
  }
  
  // function for updateing attributes
  public async updateOrCreateMany(attributes: Attribute[], category: Category) {
    // if in attributes array is attribute without id, create it
    await this.createMany(attributes.filter(item => (item.id === undefined)), category);
    // get attributes with id in array and not delete operation
    let update_fields = attributes.filter(item => (item.id !== undefined && (!item.delete || item.delete === undefined)));
    // get attributes with id in array and with delete operation
    let delete_fields = attributes.filter((item) => item.delete && item.id);
    // delete attributes if array is not empty
    if(delete_fields.length > 0)
      // delete operation
      await CategoryAttribute.query().whereIn('id', delete_fields.map((item) => String(item.id))).delete()
    // if there is row for update
    if(update_fields.length > 0) {
      // update attribute
      let updated_attributes = await category.related("attributes").updateOrCreateMany(update_fields.map(({translations, ...otherProps}) => otherProps), 'id');
      // format updated attributes so we can 
      const formated_attributes = _format(update_fields, "id");
      // update product fields translations
      await (
        async () => {
          for await (const attribute of updated_attributes)
          {
            // create translations or update existsing
            if(formated_attributes[attribute.id] && formated_attributes[attribute.id].translations)
              await attribute.related('translations').updateOrCreateMany(formated_attributes[attribute.id].translations!, ['language']);
          }
        }
      )();
    }
  }
}

/* Interfaces for controller params */
interface Attribute {
  id?: number,
  delete?: boolean,
  value: string,
  translations?: {value: string, language: AllowedLanguagesType}[]
}
