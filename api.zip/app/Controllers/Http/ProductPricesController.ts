// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

import Product from "App/Models/Product";
import ProductPrice from "App/Models/ProductPrice";

export default class ProductPricesController {
  // function for creating product price
  public async createMany(product_prices: ProductPriceRequest[], product: Product) {
    // create many product prices
    await product.related("prices").createMany(product_prices);
  }

  // function for updating product prices
  public async updateOrCreateMany(product_prices: ProductPriceRequest[], product: Product) {
    // if in product product prices array is attribute without id, create it
    await this.createMany(product_prices.filter(item => (item.id === undefined)), product);
    // get prices with id in array and not delete operation
    let update_prices = product_prices.filter(item => (item.id !== undefined && (!item.delete || item.delete === undefined)));
    // get product prices with id in array and with delete operation
    let delete_prices = product_prices.filter((item) => item.delete && item.id);
    // delete product prices from delete 
    if(delete_prices.length > 0)
      await ProductPrice.query().whereIn('id', delete_prices.map((item) => String(item.id))).delete();
    // update product prices from update 
    if(update_prices.length > 0)
      await product.related("prices").updateOrCreateMany(update_prices, 'id')

  }

}

/* Interfaces for controller params */
interface ProductPriceRequest {
  id?: number,
  delete?: boolean,
  icon_id: number,
  place_id: number,
  size: string,
  price: string
}
