import { bind } from '@adonisjs/route-model-binding';
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext';
import Category from 'App/Models/Category';
import CategoryValidator from 'App/Validators/CategoryValidator';
import CategoryAttributesController from './CategoryAttributesController';

export default class CategoriesController {

  // action for createing category
  public async create({request} : HttpContextContract) {
    // validate request
    const payload = await request.validate(CategoryValidator);
    // destruct payload
    const {name, name_plural, translations, attributes, image, type_id, is_published} = payload;
    // create new category
    const new_category = await Category.create({name, name_plural, type_id, is_published: (is_published) ? is_published : true});
    // if translations create it
    if(translations) {
      // assign languages
      await new_category.related('translations').updateOrCreateMany(translations, ['language']); 
    }
    if(attributes) {
      // instance controller 
      const attributes_controller = new CategoryAttributesController();
      // create many attributes
      await attributes_controller.createMany(attributes, new_category);
    }
    // if uploaded file move it to disk
    if(image) {
      // save uploaded file
      await image.moveToDisk('/uploads', {name: 'category-'+new_category.id+'.'+image.extname})
      // save cover image name to database for fetching
      new_category.image = '/uploads/' + image.fileName;
      // save new category update
      await new_category.save();
    }
    // load translations and attributes for returning
    await new_category.load((loader) => {
      // eager load translations and preload attributes with translations assign to it
      loader.preload("translations").preload("type").load("attributes", (attribute) => attribute.preload("translations"));
    });
    // return to user
    return new_category;
  }

  @bind()
  public async update({request}: HttpContextContract, category: Category) {
    // validate request
    const payload = await request.validate(CategoryValidator);
    // destruct payload
    const {name, name_plural, translations, attributes, image, type_id, is_published} = payload;
    if(translations) {
      // assign to translations with unique language code
      await category.related('translations').updateOrCreateMany(translations, ['language']);
    }
    if(attributes) {
      // instance controller 
      const attributes_controller = new CategoryAttributesController();
      // update many attributes
      await attributes_controller.updateOrCreateMany(attributes, category);
    }
    if(image) {
      // save uploaded file
      await image.moveToDisk('/uploads', {name: 'category-'+category.id+'.'+image.extname});;
    }
    // update category
    await category.merge({
      name, name_plural, type_id, 
      image: (image) ? '/uploads/' + image.fileName : category.image, 
      is_published: (is_published) ? is_published : category.is_published
    }).save();
    // load translations and product fields for returning
    await category.load((loader) => {
      // eager load translations and preload attributes with translations assign to it
      loader.preload("translations").preload("type").load("attributes", (attribute) => attribute.preload("translations"));
    });
    // return to user
    return category;
  }

  @bind()
  public async delete({}, category: Category) {
    // delete specific category
    await category.delete();
    // return message to user
    return {success: 'You have successfully deleted category!'}
  }

  // action for geting all
  public async getAll() {
    // get all categories
    return await Category.query().preload("translations").preload("type").preload("attributes", (attribute) => attribute.preload("translations"));
  }
  
  @bind()
  // action for getting specific category
  public async get({}, category: Category) {
    // load translations and product fields for returning
    await category.load((loader) => {
      // eager load translations and preload attributes with translations assign to it
      loader.preload("translations").preload("type").load("attributes", (attribute) => attribute.preload("translations"));
    });
    // return to user
    return category;
  }

  // action for changeing status of category
  @bind()
  public async changeStatus({request}: HttpContextContract, category: Category) {
    // get request input 
    category.is_published = request.input("is_published");
    // save to database
    await category.save();
    // return product status
    return category.is_published;
  }
}
