// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { ProductAttributeTypes, ProductFieldRequestData, ProductFieldObjectType/*, AllowedProductFieldTypes*/} from 'App/Enums/ProductFieldEnum';
import { _format } from 'App/helpers/index';
import Product from 'App/Models/Product';
import ProductField from 'App/Models/ProductField';

export default class ProductFieldsController {
  // action for createing many product fields and assign relation
  public async createMany(product_fields: ProductFieldRequestData[], product: Product) {
    // loop throught product fields
    await (
      async () => {
        for await(const field of product_fields) {
          // destruct value object
          let {translations, value} = field;
          // merge value, order, type to new product field
          // assign new field to product
          let new_field = await product.related("attributes").create({
            order: field.order,
            type: field.type,
            value: formatValueObject(value/*, field.type*/)
          });
          // if translations assigned assign translations
          if(translations) {
            // create array for translations
            let translation_array = new Array();
            for(let translated of translations) {
              let translated_object = {
                language: translated.language,
                value: formatValueObject(translated.value/*, field.type*/)
              };
              translation_array.push(translated_object);
            }
            // create many translated objects in relation
            await new_field.related("translations").updateOrCreateMany(translation_array, ['language']);
          }
        }
      }
    )();
  }
  // action for updating or creating new rows
  public async updateOrCreateMany(product_fields: ProductFieldRequestData[], product: Product) {
    // if in product fields array is attribute without id, create it
    await this.createMany(product_fields.filter(item => (item.id === undefined)), product);
    // get product fields with id in array and not delete operation
    let update_fields = product_fields.filter(item => (item.id !== undefined && (!item.delete || item.delete === undefined)));
    // get product fields with id in array and with delete operation
    let delete_fields = product_fields.filter((item) => item.delete && item.id);
    // delete product fields if array is not empty
    if(delete_fields.length > 0)
      // delete operation
      await ProductField.query().whereIn('id', delete_fields.map((item) => String(item.id))).delete()
    // if there is row for update
    if(update_fields.length > 0) {
      // update attributes, format value object based on type
      let updated_attributes = await product.related("attributes").updateOrCreateMany(
        update_fields.map(({translations, type, value, ...otherProps}) => ({
          ...otherProps,
          type,
          value: formatValueObject(value/*, type*/)
      })), 'id')
      // format updated fields so we can make operations on it
      const formated_attributes = _format(update_fields, "id");
      // update product fields translations
      await (
        async () => {
          for await (const attribute of updated_attributes)
          {
            // create translations or update existsing
            if(formated_attributes[attribute.id] && formated_attributes[attribute.id].translations)
              await attribute.related('translations').updateOrCreateMany(
                formated_attributes[attribute.id].translations!.map(({value, ...otherProps}) => ({
                  ...otherProps,
                  value: formatValueObject(value/*, attribute.type*/)
                })), ['language']);
          }
        }
      )();
    }
  }
}

// helper function for assigning value from request input
function formatValueObject(field_value: {key?: string, value: {key?: string, value: string}[]}/*, type: AllowedProductFieldTypes*/) {
  let {key, value} = field_value;
  // return formated object
  return {
    key,
    value: /*(type === ProductAttributeTypes.repeater) ?*/ value /*: value[0].value*/
  } as ProductFieldObjectType[ProductAttributeTypes.text] | ProductFieldObjectType[ProductAttributeTypes.long_text] | ProductFieldObjectType[ProductAttributeTypes.repeater];
}