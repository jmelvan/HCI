import { bind } from '@adonisjs/route-model-binding';
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Type from 'App/Models/Type'
import TypeValidator from 'App/Validators/TypeValidator';

export default class TypesController {

  public async index() {
    // get all types and preload translations model
    return await Type.query().preload('translations');
  }

  public async create({request} : HttpContextContract) {
    // validate request
    const payload = await request.validate(TypeValidator);
    // destruct payload
    const {name, name_plural, collection_name, translations} = payload;
    // create new type
    const new_type = await Type.create({name, name_plural, collection_name});
    // if translations assign them
    if(translations) {
      // assign languages
      await new_type.related('translations').updateOrCreateMany(translations, ['language']); 
      // load translations
      await new_type.load('translations');
    }
    // return to user
    return new_type;
  }

  @bind()
  public async update({request}: HttpContextContract, type: Type) {
    // validate request
    const payload = await request.validate(TypeValidator);
    // desctruct payload
    const {name, name_plural, translations} = payload;
    // update type
    await type.merge({name, name_plural}).save();
    // if translations assign them
    if(translations) {
      // assign to translations with unique language code
      await type.related('translations').updateOrCreateMany(translations, ['language']);
      // load translations for fetching to user
      await type.load('translations');
    }
    return type;
  }

  @bind()
  public async delete({}, type:Type) {
    // delete specific type
    await type.delete();
    // return message to user
    return {success: 'You have successfully deleted type!'}
  }
}
