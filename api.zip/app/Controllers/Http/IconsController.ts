// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

import Icon from "App/Models/Icon";

export default class IconsController {

  // action for getting all icons
  public async index({}) {
    // icons get
    return await Icon.all()
  }

}
