import { bind } from '@adonisjs/route-model-binding';
import Hash from '@ioc:Adonis/Core/Hash'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import MessageException from 'App/Exceptions/MessageException';
import LoginValidator from 'App/Validators/users/LoginValidator';
import UpdateUserValidator from 'App/Validators/users/UpdateUser';

export default class UsersController {

  // route for updateing user data
  @bind()
  public async update({request, auth} : HttpContextContract) {
    // make request validation
    const payload = await request.validate(UpdateUserValidator);
    // desctruct payload
    const {password, oldPassword} = payload;
    // check password
    if(!await Hash.verify(auth.user!.password, oldPassword))
      throw new MessageException('You have inputted wrong old password', 422);
    // change password
    auth.user!.password = password;
    // save model
    await auth.user!.save();
    // return success message
    return {success: 'User data changed successfully.'}

  }

  // route for fetching user data
  public async index({auth}: HttpContextContract) {
    return auth.user;
  }

  // route for login
  public async login({request, auth} : HttpContextContract) {
    // make request validation
    const payload = await request.validate(LoginValidator);
    // desctruct payload
    const {password, email} = payload;
    // try to login and create auth token
    const token = await auth.use('api').attempt(email, password, {expiresIn: "10 days"});
    // response token to user
    return token;
  }
}
