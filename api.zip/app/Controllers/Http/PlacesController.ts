import { bind } from '@adonisjs/route-model-binding';
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import MessageException from 'App/Exceptions/MessageException';
import Category from 'App/Models/Category';
import Place from 'App/Models/Place';
import PlaceValidator from 'App/Validators/PlaceValidator';

export default class PlacesController {

  public async create({request} : HttpContextContract) {
    // validate request
    const payload = await request.validate(PlaceValidator);
    // destruct payload
    const {name, image, slug} = payload;
    // if not slug provided
    if(!slug)
      throw new MessageException('You need to provide slug for creation of new place.', 422);
    // create new place
    const new_place = new Place();
    // if uploaded logo move it to disk
    if(image) {
      // save uploaded file
      await image.moveToDisk('/uploads', {name: 'logo-'+slug+'.'+image.extname})
    }
    // assign values to new place object and save it
    await new_place.merge({
      name,
      image: (image) ? '/uploads/' + image.fileName : '',
      slug
    }).save()
    // return to user
    return new_place;
  }

  @bind()
  public async update({request}: HttpContextContract, place: Place) {
    // validate request
    const payload = await request.validate(PlaceValidator);
    // destruct payload
    const {name, image, slug} = payload;
    // if slug inputed update it
    if(slug)
      place.slug = slug;
    // if uploaded logo move it to disk
    if(image) {
      // save uploaded file
      await image.moveToDisk('/uploads', {name: 'logo-'+place.slug+'.'+image.extname})
    }
    // update place data
    await place.merge({
      name,
      image: (image) ? '/uploads/' + image!.fileName : place.image
    }).save();
    // return to user
    return place;
  }

  @bind()
  public async delete({}, place: Place) {
    // delete specific place
    await place.delete();
    // return message to user
    return {success: 'You have successfully deleted place!'}
  }

  // action for getting all places
  public async getAll() {
    // return all places
    return Place.all();
  }

  // action for getting single place
  @bind()
  public async get({}, place: Place) {
    // get requested place
    return place;
  }

  @bind()
  // action for getting place categories
  public async getCategories({}, place: Place) {
    // initialize categories array
    let categories = {} as Record<string, Category>;
    // load place products
    await place.load("products");
    // go through place products and load categories
    await (async () => {
      for await (let product of place.products) {
        // if product is published and category is not already loaded load it and assign it to categories object
        if(product.is_published && !categories[product.category_id]) {
          // load category and it translation
          await product.load("category", (category) => 
            category.preload("translations")
          );
          // assign to categories object values
          categories = {...categories, [product.category_id]: product.category}
        }
      }
    })();

    // return array to user and only published categories
    return Object.values(categories).filter((category) => category.is_published);
  }

  @bind()
  // action for getting place products by category id
  public async getProducts({}, place: Place, category: Category) {
    // load cattegory attributes
    await category.load("attributes", (attribute) => attribute.preload("translations"))
    // make filter options
    let filters = category.attributes;
    // return to user and preload translations
    let products = await place.related("products").
    query().
    where((query) => query.
      where('category_id', category.id).
      where('is_published', true)
    ).
    preload("translations").
    preload("tags");

    // return to user products and filter options
    return {
      products,
      filters
    }

  }
}
