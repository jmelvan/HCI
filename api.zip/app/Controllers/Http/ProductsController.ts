import { bind } from '@adonisjs/route-model-binding';
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { _format } from 'App/helpers';
import CategoryAttribute from 'App/Models/CategoryAttribute';
import Product from 'App/Models/Product';
import ProductValidator from 'App/Validators/ProductValidator'
import ProductFieldsController from './ProductFieldsController';
import ProductPricesController from './ProductPricesController';

export default class ProductsController {

  @bind()
  // action for getting product data
  public async index({}, product: Product) {
    await product.load((loader) => 
      loader.load("attributes", (attribute) => attribute.preload("translations").orderBy('order'))
      .load("prices", (price) => price.preload("icon"))
      .load("tags")
    )
    return product;
  }

  // action for creating new product
  public async create({request} : HttpContextContract) {
    // validate request
    const payload = await request.validate(ProductValidator);
    // destruct payload
    const {image, category_id, attributes, name, is_published, translations, tags, places, prices} = payload;
    // create new product
    const product = await Product.create({name, category_id, is_published: (is_published) ? is_published : true});
    // assign places if exits
    if(places)
      // sync places
      await product.related("places").sync(places);
    // assign tags if exits
    if(tags) {
      // get allowed tags ( need to exists in category id supplied  )
      let category_attributes = await CategoryAttribute.findMany(tags);
      await product.related("tags").sync(category_attributes.flatMap((attribute) => attribute.category_id === category_id ? [attribute.id] : []))
    }
    // if translations assign it
    if(translations)
      // assign languages
      await product.related('translations').updateOrCreateMany(translations, ['language']);
    // if prices assign it
    if(prices) {
      // instance controller for prices
      const prices_controller = new ProductPricesController();
      // create new product prices 
      await prices_controller.createMany(prices, product);
    }
    // if assigned attributes
    if(attributes) {
      // instance product fields controller
      const fields_controller = new ProductFieldsController();
      // create new product fields and assign it to product
      await fields_controller.createMany(attributes, product);
    }
    // if uploaded file move it to disk
    if(image) {
      // save uploaded file
      await image.moveToDisk('/uploads', {name: 'product-'+product.id+'.'+image.extname})
      // save image name to database for fetching
      product.image = '/uploads/' + image.fileName;
      // save new product update
      await product.save();
    }
    // eager load data
    await product.load((loader) => {
      loader
      .preload("translations")
      .preload("places")
      .load("prices")
      .load("attributes", (attributes) => attributes.preload("translations").orderBy('order'))
      .load("tags");
    })
    // return to user, make tags and places as arrays of ids
    return {
      // serialize object
      ...product.serialize(),
      // places to array
      places: product.places.map((place) => place.id),
      // tags to array
      tags: product.tags.map((tag) => tag.id)
    };
  }

  // action for updating product
  @bind()
  public async update({request}: HttpContextContract, product: Product) {
    // validate request
    const payload = await request.validate(ProductValidator);
    // destruct payload
    const {image, category_id, attributes, name, is_published, translations, tags, places, prices} = payload;
    // assign places if exits
    if(places) 
      await product.related("places").sync(places);
    // assign tags if exits
    if(tags) {
      // get allowed tags ( need to exists in category id supplied  )
      let category_attributes = await CategoryAttribute.findMany(tags);
      await product.related("tags").sync(category_attributes.flatMap((attribute) => attribute.category_id === category_id ? [attribute.id] : []))
    }
    // if translations assigned
    if(translations) {
      // assign languages
      await product.related('translations').updateOrCreateMany(translations, ['language']);
    }
    // if assigned attributes
    if(attributes) {
      // instance product fields controller
      const fields_controller = new ProductFieldsController();
      // create new product fields and assign it to product
      await fields_controller.updateOrCreateMany(attributes, product);
    }
    // if prices assign it
    if(prices) {
      // instance controller for prices
      const prices_controller = new ProductPricesController();
      // create new product prices 
      await prices_controller.updateOrCreateMany(prices, product);
    }
    // if image uploaded
    if(image) {
      // save uploaded file
      await image.moveToDisk('/uploads', {name: 'product-'+product.id+'.'+image.extname})
    }
    // save product update
    await product.merge({ name, category_id, image: (image) ? '/uploads/' + image.fileName : product.image, is_published: (is_published) ? is_published : product.is_published}).save();
    // eager load data
    await product.load((loader) => {
      loader
      .preload("translations")
      .preload("places")
      .load("prices")
      .load("attributes", (attributes) => attributes.preload("translations").orderBy('order'))
      .load("tags");
    })
    // return to user, make tags and places as arrays of ids
    return {
      // serialize object
      ...product.serialize(),
      // places to array
      places: product.places.map((place) => place.id),
      // tags to array
      tags: product.tags.map((tag) => tag.id)
    };
  }

  @bind()
  public async delete({}, product: Product) {
    // delete specific product
    await product.delete();
    // return message to user
    return {success: 'You have successfully deleted product!'}
  }

  // action for getting all product data
  public async getAll() {
    // get all products
    return await Product.query().preload("places").preload("category");
  }

  @bind()
  public async get({}, product: Product) {
    // get all data for specific product
    await product.load((loader) => 
      loader
      .preload("translations")
      .preload("places")
      .load("prices")
      .load("attributes", (attributes) => attributes.preload("translations").orderBy('order'))
      .load("tags")
    );

    // response to user, make places & tags as array of ids
    return {
      // serialize object
      ...product.serialize(),
      // places to array
      places: product.places.map((place) => place.id),
      // tags to array
      tags: product.tags.map((tag) => tag.id)
    };
  }

  // action for changeing status of product
  @bind()
  public async changeStatus({request}: HttpContextContract, product: Product) {
    // get request input 
    product.is_published = request.input("is_published");
    // save to database
    await product.save();
    // return product status
    return product.is_published;
  }
}
